"""
Camera Alert System
====================
Integrates the PersonTracker with ntfy.sh to send instant phone
alerts when a person is detected by the camera.

Also provides the Flask endpoints for the live video feed so the
Command Center dashboard can embed the camera in its right panel.

Usage:
    from security.camera_alerts import SecuritySuite

    suite = SecuritySuite(camera_index=0, dashboard_port=5050)
    suite.start()
    # → camera running
    # → ntfy.sh alerts firing
    # → /video_feed endpoint available in dashboard
"""

import logging
import os
import threading
import time
from datetime import datetime
from typing import Dict, Optional

logger = logging.getLogger(__name__)

NTFY_TOPIC = os.getenv("NTFY_TOPIC", "macro-intel-alerts")


class SecuritySuite:
    """
    Complete security suite: detector + re-ID + alerts + video stream.

    Integrates all security components into one object that the
    Command Center orchestrator can start with a single call.
    """

    def __init__(
        self,
        camera_index: int = 0,
        dashboard_port: int = 5050,
        alert_cooldown_sec: int = 60,
        min_confidence: float = 0.45,
    ):
        self.camera_index    = camera_index
        self.dashboard_port  = dashboard_port
        self.alert_cooldown  = alert_cooldown_sec
        self.min_confidence  = min_confidence

        self._detector  = None
        self._tracker   = None
        self._alerter   = None
        self._tunnel    = None
        self._running   = False

        self._alert_log: list = []
        self._last_alert_time: Dict[str, float] = {}

    def start(self, enable_ngrok: bool = True) -> Dict:
        """
        Start all security components.
        Returns a dict with status and public URL if ngrok is active.
        """
        result = {"camera": False, "ngrok_url": None}

        # 1. Start alerter
        try:
            from pipeline.alerts_scheduler import NtfyAlerter
            self._alerter = NtfyAlerter(topic=NTFY_TOPIC)
            logger.info("NtfyAlerter initialized")
        except Exception as e:
            logger.warning(f"Alerter init failed: {e}")

        # 2. Start person detector + tracker
        try:
            from security.humanizer       import PersonDetector
            from security.reidentification import PersonTracker

            self._detector = PersonDetector(
                camera_index=self.camera_index,
                confidence_threshold=self.min_confidence,
                target_fps=15,
            )
            self._tracker = PersonTracker(
                detector=self._detector,
                on_new_person=self._handle_new_person,
                on_reidentified=self._handle_reidentified,
            )

            ok = self._tracker.start()
            result["camera"] = ok

            if ok:
                logger.info(f"Camera started (index={self.camera_index})")
            else:
                logger.warning(f"Camera {self.camera_index} failed to start")

        except ImportError as e:
            logger.error(f"Security dependencies missing: {e}")
            logger.error("Install: pip install ultralytics opencv-python-headless")

        # 3. Start ngrok
        if enable_ngrok:
            try:
                from security.ngrok_tunnel import NgrokTunnel
                self._tunnel = NgrokTunnel(port=self.dashboard_port)
                public_url   = self._tunnel.start()
                result["ngrok_url"] = public_url

                # Send startup alert with URL
                if self._alerter and public_url:
                    self._alerter.send(
                        title="🟢 Security Suite Online",
                        message=(
                            f"Camera active at port {self.dashboard_port}\n"
                            f"Remote access: {public_url}\n"
                            f"Video feed: {public_url}/video_feed"
                        ),
                        priority="low",
                        tags=["white_check_mark"],
                    )
            except Exception as e:
                logger.warning(f"Ngrok start failed: {e}")

        self._running = True
        return result

    def stop(self):
        """Stop all security components."""
        self._running = False
        if self._tracker:
            self._tracker.stop()
        if self._tunnel:
            self._tunnel.stop()
        logger.info("SecuritySuite stopped")

    def _handle_new_person(self, detection, frame_result):
        """Callback: new unknown person detected."""
        person_id = detection.person_id or "unknown"

        # Cooldown check
        now = time.time()
        if now - self._last_alert_time.get(person_id, 0) < self.alert_cooldown:
            return
        self._last_alert_time[person_id] = now

        # Log alert
        alert = {
            "type":      "new_person",
            "person_id": person_id,
            "confidence":detection.confidence,
            "timestamp": datetime.now().isoformat(),
        }
        self._alert_log.append(alert)
        logger.warning(f"NEW PERSON DETECTED: {person_id} (conf={detection.confidence:.0%})")

        # Send phone alert
        if self._alerter:
            camera_url = self._tunnel.camera_url if self._tunnel else None
            self._alerter.send_camera_alert(
                person_id=person_id,
                is_new=True,
                camera_url=camera_url,
            )

    def _handle_reidentified(self, detection, frame_result):
        """Callback: known person re-identified (no alert, just log)."""
        logger.debug(f"Re-identified: {detection.person_id}")

    def get_jpeg_frame(self) -> Optional[bytes]:
        """Get latest annotated camera frame as JPEG bytes."""
        if self._detector:
            return self._detector.get_jpeg_bytes()
        return None

    def get_status(self) -> Dict:
        """Return current status of all components."""
        return {
            "camera_running":  self._detector is not None and self._detector._running,
            "ngrok_url":       self._tunnel.public_url if self._tunnel else None,
            "gallery_size":    self._tracker.gallery.gallery_size if self._tracker else 0,
            "alert_count":     len(self._alert_log),
            "detector_stats":  self._detector.stats if self._detector else {},
            "gallery_stats":   self._tracker.gallery.stats if self._tracker else {},
            "recent_alerts":   self._alert_log[-10:],
        }

    def register_flask_routes(self, app, socketio=None):
        """
        Register video feed and security API routes on an existing Flask app.
        Call this from dashboard/app.py's create_app().
        """
        from flask import Response, jsonify

        @app.route("/video_feed")
        def video_feed():
            from security.humanizer import mjpeg_generator
            if self._detector is None:
                return "Camera not available", 503
            return Response(
                mjpeg_generator(self._detector, fps=15),
                mimetype="multipart/x-mixed-replace; boundary=frame",
            )

        @app.route("/api/security")
        def security_status():
            return jsonify(self.get_status())

        @app.route("/api/security/alerts")
        def security_alerts():
            return jsonify({
                "alerts":    self._alert_log[-50:],
                "total":     len(self._alert_log),
                "timestamp": datetime.utcnow().isoformat(),
            })

        logger.info("Security routes registered: /video_feed, /api/security")


# ─────────────────────────────────────────────────────────────
# Standalone camera test (run this file directly to test camera)
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO)

    cam_idx = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    print(f"\nTesting camera {cam_idx} with YOLOv8 person detection...")
    print("Press Ctrl+C to stop\n")

    try:
        from security.humanizer import PersonDetector
        import cv2

        detector = PersonDetector(camera_index=cam_idx, target_fps=20)
        if not detector.start():
            print(f"ERROR: Cannot open camera {cam_idx}")
            sys.exit(1)

        print("Camera running. Displaying live feed with person detection...")
        while True:
            result = detector.get_latest()
            if result is not None:
                cv2.imshow("Person Detector — press Q to quit", result.annotated_frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            time.sleep(0.033)

    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        detector.stop()
        cv2.destroyAllWindows()
