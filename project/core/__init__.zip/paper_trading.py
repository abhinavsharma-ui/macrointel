"""
Virtual Paper Trading Broker
==============================
"Paper Trade First. Never put real money into a new model."

This module simulates a complete broker with:
  - Virtual account with realistic fills
  - Slippage and commission simulation
  - Position tracking and P&L
  - Performance logging for signal validation
  - Risk management (position limits, stop-losses, max drawdown kill switch)

Use this for 30+ days before any live deployment.
"""

import logging
from datetime import datetime, timezone
from typing import Optional, Dict, List
from dataclasses import dataclass, field
from enum import Enum

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class OrderSide(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderStatus(str, Enum):
    PENDING = "pending"
    FILLED = "filled"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


@dataclass
class Order:
    symbol: str
    side: OrderSide
    quantity: int
    order_type: str = "market"  # "market" | "limit"
    limit_price: Optional[float] = None
    signal_source: str = ""     # Which model generated this signal
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    filled_at: Optional[datetime] = None
    filled_price: Optional[float] = None
    commission: float = 0.0
    status: OrderStatus = OrderStatus.PENDING
    order_id: str = ""

    def __post_init__(self):
        if not self.order_id:
            self.order_id = f"VPT-{self.symbol}-{int(self.created_at.timestamp())}"


@dataclass
class Position:
    symbol: str
    quantity: int              # Positive = long, negative = short
    avg_cost: float
    market: str = "US"
    opened_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0

    @property
    def cost_basis(self) -> float:
        return abs(self.quantity) * self.avg_cost

    def update_market_price(self, current_price: float):
        self.unrealized_pnl = (current_price - self.avg_cost) * self.quantity


class VirtualBroker:
    """
    Complete paper trading simulator.
    
    Designed to be a drop-in replacement for a real broker API.
    Same interface — just doesn't use real money.
    """

    def __init__(
        self,
        initial_capital: float = 100_000,
        max_position_pct: float = 0.10,   # Max 10% per position
        max_drawdown_pct: float = 0.20,   # Kill switch at 20% portfolio drawdown
        market: str = "US",
    ):
        self.initial_capital = initial_capital
        self.cash = initial_capital
        self.max_position_pct = max_position_pct
        self.max_drawdown_pct = max_drawdown_pct
        self.market = market

        self.positions: Dict[str, Position] = {}
        self.orders: List[Order] = []
        self.trade_log: List[Dict] = []
        self._kill_switch_activated = False
        self._peak_portfolio_value = initial_capital

        from core.backtesting import TransactionCostModel
        self._cost_model = TransactionCostModel()

        logger.info(f"Virtual broker initialized: ${initial_capital:,.0f} capital")

    # ── Order execution ───────────────────────────────────────

    def submit_order(self, order: Order, current_price: float) -> Dict:
        """Submit and simulate-fill a market order."""
        if self._kill_switch_activated:
            return {"status": "rejected", "reason": "Kill switch active — portfolio protection"}

        # Risk checks
        rejection = self._risk_check(order, current_price)
        if rejection:
            order.status = OrderStatus.REJECTED
            logger.warning(f"Order rejected: {order.symbol} — {rejection}")
            return {"status": "rejected", "reason": rejection}

        # Simulate fill with slippage
        fill_price = self._simulate_fill_price(order, current_price)
        commission = self._cost_model.compute_cost(
            trade_value=abs(order.quantity) * fill_price,
            market=self.market,
        ) * abs(order.quantity) * fill_price

        # Execute the fill
        order.filled_price = fill_price
        order.commission = commission
        order.filled_at = datetime.now(timezone.utc)
        order.status = OrderStatus.FILLED

        self._update_position(order)
        self._update_cash(order, fill_price, commission)
        self.orders.append(order)

        trade_record = {
            "order_id": order.order_id,
            "symbol": order.symbol,
            "side": order.side,
            "quantity": order.quantity,
            "fill_price": round(fill_price, 4),
            "commission": round(commission, 4),
            "slippage_pct": round((fill_price / current_price - 1) * 100, 4),
            "cash_after": round(self.cash, 2),
            "portfolio_value": round(self.portfolio_value, 2),
            "signal_source": order.signal_source,
            "filled_at": order.filled_at.isoformat(),
        }
        self.trade_log.append(trade_record)

        logger.info(
            f"FILL: {order.side.upper()} {order.quantity}x {order.symbol} "
            f"@ ${fill_price:.2f} (slippage: {trade_record['slippage_pct']:.3f}%)"
        )

        return {"status": "filled", "trade": trade_record}

    def update_prices(self, prices: Dict[str, float]) -> Dict:
        """
        Update all position prices and compute P&L.
        Call this on every price tick.
        """
        total_unrealized = 0
        for symbol, pos in self.positions.items():
            if symbol in prices:
                pos.update_market_price(prices[symbol])
                total_unrealized += pos.unrealized_pnl

        # Kill switch check
        pv = self.portfolio_value
        self._peak_portfolio_value = max(self._peak_portfolio_value, pv)
        current_drawdown = (pv - self._peak_portfolio_value) / self._peak_portfolio_value

        if current_drawdown <= -self.max_drawdown_pct and not self._kill_switch_activated:
            self._kill_switch_activated = True
            logger.critical(
                f"⚠️  KILL SWITCH ACTIVATED: Portfolio drawdown {current_drawdown:.1%} "
                f"exceeds limit {-self.max_drawdown_pct:.1%}"
            )

        return {
            "portfolio_value": round(pv, 2),
            "cash": round(self.cash, 2),
            "unrealized_pnl": round(total_unrealized, 2),
            "drawdown_pct": round(current_drawdown * 100, 2),
            "kill_switch": self._kill_switch_activated,
        }

    def close_position(self, symbol: str, current_price: float) -> Dict:
        """Close an existing position."""
        if symbol not in self.positions:
            return {"status": "no_position"}

        pos = self.positions[symbol]
        side = OrderSide.SELL if pos.quantity > 0 else OrderSide.BUY
        order = Order(
            symbol=symbol,
            side=side,
            quantity=abs(pos.quantity),
            signal_source="manual_close",
        )
        return self.submit_order(order, current_price)

    # ── Portfolio reporting ───────────────────────────────────

    @property
    def portfolio_value(self) -> float:
        """Total portfolio value including all positions at current prices."""
        position_value = sum(
            pos.quantity * (pos.avg_cost + pos.unrealized_pnl / max(abs(pos.quantity), 1))
            for pos in self.positions.values()
        )
        return self.cash + position_value

    @property
    def total_return_pct(self) -> float:
        return (self.portfolio_value / self.initial_capital - 1) * 100

    def get_summary(self) -> Dict:
        """Complete portfolio summary."""
        realized_pnl = sum(t.get("realized_pnl", 0) for t in self.trade_log)
        winning_trades = sum(1 for t in self.trade_log if t.get("realized_pnl", 0) > 0)
        total_trades = len([t for t in self.trade_log if t.get("realized_pnl") is not None])

        return {
            "initial_capital": self.initial_capital,
            "current_portfolio_value": round(self.portfolio_value, 2),
            "cash": round(self.cash, 2),
            "total_return_pct": round(self.total_return_pct, 2),
            "realized_pnl": round(realized_pnl, 2),
            "total_commissions_paid": round(sum(t.get("commission", 0) for t in self.trade_log), 2),
            "open_positions": len(self.positions),
            "total_trades": len(self.orders),
            "win_rate_pct": round(winning_trades / max(total_trades, 1) * 100, 1),
            "kill_switch_active": self._kill_switch_activated,
            "positions": {
                sym: {
                    "quantity": pos.quantity,
                    "avg_cost": round(pos.avg_cost, 4),
                    "unrealized_pnl": round(pos.unrealized_pnl, 2),
                }
                for sym, pos in self.positions.items()
            },
        }

    def get_trade_dataframe(self) -> pd.DataFrame:
        """Return trade history as a DataFrame for analysis."""
        if not self.trade_log:
            return pd.DataFrame()
        return pd.DataFrame(self.trade_log)

    # ── Internal helpers ──────────────────────────────────────

    def _simulate_fill_price(self, order: Order, market_price: float) -> float:
        """Simulate realistic fill with slippage."""
        from core.backtesting import TransactionCostModel
        base_slippage = TransactionCostModel().base_slippage_pct

        if order.side == OrderSide.BUY:
            return market_price * (1 + base_slippage)  # Pay a little more to buy
        else:
            return market_price * (1 - base_slippage)  # Get a little less when selling

    def _risk_check(self, order: Order, current_price: float) -> Optional[str]:
        """Pre-trade risk checks. Return error message if rejected."""
        order_value = abs(order.quantity) * current_price

        # Insufficient cash
        if order.side == OrderSide.BUY and order_value > self.cash:
            return f"Insufficient cash: need ${order_value:,.0f}, have ${self.cash:,.0f}"

        # Position size limit
        max_position_value = self.portfolio_value * self.max_position_pct
        if order_value > max_position_value:
            return (f"Position too large: ${order_value:,.0f} exceeds "
                    f"${max_position_value:,.0f} limit ({self.max_position_pct:.0%})")

        return None

    def _update_position(self, order: Order):
        """Update position tracking after a fill."""
        symbol = order.symbol
        qty = order.quantity if order.side == OrderSide.BUY else -order.quantity

        if symbol in self.positions:
            pos = self.positions[symbol]
            new_qty = pos.quantity + qty

            if new_qty == 0:
                del self.positions[symbol]
            elif (pos.quantity > 0) == (qty > 0):
                # Adding to existing position — compute new average cost
                total_cost = pos.quantity * pos.avg_cost + qty * order.filled_price
                pos.quantity = new_qty
                pos.avg_cost = total_cost / new_qty
            else:
                # Partial close — realize P&L on closed portion
                closed_qty = min(abs(pos.quantity), abs(qty))
                realized = closed_qty * (order.filled_price - pos.avg_cost) * np.sign(pos.quantity)
                pos.realized_pnl += realized
                if abs(qty) > abs(pos.quantity):
                    # Flip position
                    self.positions[symbol] = Position(
                        symbol=symbol,
                        quantity=new_qty,
                        avg_cost=order.filled_price,
                        market=self.market,
                    )
                else:
                    pos.quantity = new_qty
        else:
            self.positions[symbol] = Position(
                symbol=symbol,
                quantity=qty,
                avg_cost=order.filled_price,
                market=self.market,
            )

    def _update_cash(self, order: Order, fill_price: float, commission: float):
        """Update cash balance after trade."""
        trade_value = abs(order.quantity) * fill_price
        if order.side == OrderSide.BUY:
            self.cash -= (trade_value + commission)
        else:
            self.cash += (trade_value - commission)
