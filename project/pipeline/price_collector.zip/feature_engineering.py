"""
Feature Engineering Pipeline
==============================
Converts raw OHLCV price data into a rich feature matrix for the AI models.

Features computed:
  Momentum     — RSI(14), MACD, Rate-of-Change (5/10/20d), Williams %R
  Trend        — EMA(9/21/50/200), Price vs EMA, Golden/Death cross
  Volatility   — ATR(14), Bollinger Band width, Historical vol (10/30d)
  Volume       — Volume ratio, On-Balance Volume (OBV), Volume Z-score
  Composite    — Momentum composite, Alpha signal (combined score)
  Sentiment    — Joined from sentiment pipeline if available
"""

import logging
from typing import Dict, Optional

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────
# Individual indicator functions
# ─────────────────────────────────────────────────────────────

def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta  = close.diff()
    gain   = delta.clip(lower=0)
    loss   = -delta.clip(upper=0)
    avg_g  = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_l  = loss.ewm(com=period - 1, min_periods=period).mean()
    rs     = avg_g / avg_l.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def _macd(close: pd.Series, fast=12, slow=26, signal=9):
    ema_fast   = close.ewm(span=fast,   adjust=False).mean()
    ema_slow   = close.ewm(span=slow,   adjust=False).mean()
    macd_line  = ema_fast - ema_slow
    signal_line= macd_line.ewm(span=signal, adjust=False).mean()
    histogram  = macd_line - signal_line
    return macd_line, signal_line, histogram


def _atr(high: pd.Series, low: pd.Series, close: pd.Series, period=14) -> pd.Series:
    tr = pd.concat([
        high - low,
        (high - close.shift()).abs(),
        (low  - close.shift()).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(com=period - 1, min_periods=period).mean()


def _bollinger_bands(close: pd.Series, period=20, std_dev=2):
    mid   = close.rolling(period).mean()
    sigma = close.rolling(period).std()
    upper = mid + std_dev * sigma
    lower = mid - std_dev * sigma
    width = (upper - lower) / mid.replace(0, np.nan)
    pct_b = (close - lower) / (upper - lower).replace(0, np.nan)
    return mid, upper, lower, width, pct_b


def _obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    direction = close.diff().apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
    return (direction * volume).cumsum()


def _williams_r(high: pd.Series, low: pd.Series, close: pd.Series, period=14) -> pd.Series:
    highest = high.rolling(period).max()
    lowest  = low.rolling(period).min()
    return -100 * (highest - close) / (highest - lowest).replace(0, np.nan)


def _stochastic(high: pd.Series, low: pd.Series, close: pd.Series, k=14, d=3):
    lowest  = low.rolling(k).min()
    highest = high.rolling(k).max()
    k_pct   = 100 * (close - lowest) / (highest - lowest).replace(0, np.nan)
    d_pct   = k_pct.rolling(d).mean()
    return k_pct, d_pct


# ─────────────────────────────────────────────────────────────
# Main pipeline
# ─────────────────────────────────────────────────────────────

class FeaturePipeline:
    """
    Converts {symbol: OHLCV DataFrame} → {symbol: feature DataFrame}

    Usage:
        pipeline = FeaturePipeline()
        features = pipeline.build_feature_matrix(
            price_data={"AAPL": df_aapl, ...},
            sentiment_data=sentiment_df,   # optional
        )
        # features["AAPL"] is a DataFrame ready for ML inference
    """

    def build_feature_matrix(
        self,
        price_data: Dict[str, pd.DataFrame],
        sentiment_data: Optional[pd.DataFrame] = None,
    ) -> Dict[str, pd.DataFrame]:
        """Build feature matrices for all symbols."""
        results = {}
        for symbol, ohlcv in price_data.items():
            try:
                df = self._engineer_features(ohlcv.copy(), symbol, sentiment_data)
                if df is not None and not df.empty:
                    results[symbol] = df
            except Exception as e:
                logger.error(f"Feature engineering failed for {symbol}: {e}")
        return results

    def _engineer_features(
        self,
        df: pd.DataFrame,
        symbol: str,
        sentiment_data: Optional[pd.DataFrame],
    ) -> Optional[pd.DataFrame]:
        """Build all features for a single symbol."""
        if len(df) < 60:
            logger.warning(f"{symbol}: insufficient data ({len(df)} rows), need ≥60")
            return None

        close  = df["close"]
        high   = df["high"]
        low    = df["low"]
        volume = df["volume"]
        feat   = pd.DataFrame(index=df.index)

        # ── Momentum ──────────────────────────────────────────
        feat["rsi_14"]     = _rsi(close, 14)
        feat["rsi_9"]      = _rsi(close, 9)
        feat["rsi_21"]     = _rsi(close, 21)
        macd_l, macd_s, macd_h = _macd(close)
        feat["macd"]       = macd_l
        feat["macd_signal"]= macd_s
        feat["macd_hist"]  = macd_h
        feat["roc_5"]      = close.pct_change(5)
        feat["roc_10"]     = close.pct_change(10)
        feat["roc_20"]     = close.pct_change(20)
        feat["williams_r"] = _williams_r(high, low, close)
        k, d               = _stochastic(high, low, close)
        feat["stoch_k"]    = k
        feat["stoch_d"]    = d

        # ── Trend (EMAs) ──────────────────────────────────────
        for span in [9, 21, 50, 200]:
            feat[f"ema_{span}"] = close.ewm(span=span, adjust=False).mean()

        feat["price_vs_ema9"]   = (close / feat["ema_9"]  - 1) * 100
        feat["price_vs_ema21"]  = (close / feat["ema_21"] - 1) * 100
        feat["price_vs_ema50"]  = (close / feat["ema_50"] - 1) * 100
        feat["price_vs_ema200"] = (close / feat["ema_200"]- 1) * 100
        feat["golden_cross"]    = (feat["ema_50"] > feat["ema_200"]).astype(float)
        feat["ema_slope_9"]     = feat["ema_9"].pct_change(3)

        # ── Volatility ────────────────────────────────────────
        feat["atr_14"]      = _atr(high, low, close)
        feat["atr_pct"]     = feat["atr_14"] / close
        mid, bb_up, bb_lo, bb_width, bb_pct = _bollinger_bands(close)
        feat["bb_width"]    = bb_width
        feat["bb_pct"]      = bb_pct
        feat["hist_vol_10"] = close.pct_change().rolling(10).std() * np.sqrt(252)
        feat["hist_vol_30"] = close.pct_change().rolling(30).std() * np.sqrt(252)
        feat["vol_ratio"]   = feat["hist_vol_10"] / feat["hist_vol_30"].replace(0, np.nan)

        # ── Volume ────────────────────────────────────────────
        vol_ma20          = volume.rolling(20).mean()
        feat["vol_ratio_20"] = volume / vol_ma20.replace(0, np.nan)
        feat["obv"]          = _obv(close, volume)
        feat["obv_slope"]    = feat["obv"].pct_change(5)
        vol_z                = (volume - vol_ma20) / volume.rolling(20).std().replace(0, np.nan)
        feat["vol_zscore"]   = vol_z.clip(-3, 3)

        # ── Price patterns ────────────────────────────────────
        feat["gap_up"]         = ((df["open"] - df["close"].shift()) / df["close"].shift()).clip(-0.1, 0.1)
        feat["candle_body"]    = (close - df["open"]) / df["open"]
        feat["upper_wick"]     = (high - close.clip(lower=df["open"])) / close.clip(lower=1)
        feat["lower_wick"]     = (close.clip(upper=df["open"]) - low) / close.clip(lower=1)
        feat["52w_high_ratio"] = close / close.rolling(252).max().replace(0, np.nan)
        feat["52w_low_ratio"]  = close / close.rolling(252).min().replace(0, np.nan)

        # ── Composite momentum score ──────────────────────────
        rsi_norm   = (50 - feat["rsi_14"]) / 50          # −1 (overbought) to +1 (oversold)
        macd_norm  = feat["macd_hist"].clip(-2, 2) / 2
        roc_norm   = feat["roc_10"].clip(-0.1, 0.1) / 0.1
        bb_norm    = (0.5 - feat["bb_pct"]).clip(-0.5, 0.5) / 0.5
        obv_norm   = feat["obv_slope"].clip(-0.1, 0.1) / 0.1

        feat["momentum_composite"] = (
            0.25 * rsi_norm +
            0.25 * macd_norm +
            0.20 * roc_norm +
            0.15 * bb_norm +
            0.15 * obv_norm
        ).clip(-1, 1)

        # ── Regime flags ──────────────────────────────────────
        feat["trend_regime"]  = (feat["ema_50"] > feat["ema_200"]).astype(int)  # 1=bull, 0=bear
        feat["vol_regime"]    = (feat["hist_vol_30"] > feat["hist_vol_30"].rolling(60).mean()).astype(int)

        # ── Sentiment join (if available) ─────────────────────
        if sentiment_data is not None:
            try:
                sym_sent = sentiment_data.xs(symbol, level="symbol") if "symbol" in sentiment_data.index.names else None
                if sym_sent is not None and not sym_sent.empty:
                    feat = feat.join(sym_sent[["compound_score", "article_count"]], how="left")
                    feat["compound_score"]  = feat["compound_score"].fillna(0)
                    feat["article_count"]   = feat["article_count"].fillna(0)
                else:
                    feat["compound_score"] = 0.0
                    feat["article_count"]  = 0.0
            except Exception:
                feat["compound_score"] = 0.0
                feat["article_count"]  = 0.0
        else:
            feat["compound_score"] = 0.0
            feat["article_count"]  = 0.0

        # ── Alpha signal (final composite including sentiment) ─
        sent_norm = feat["compound_score"].clip(-1, 1)
        feat["alpha_signal"] = (
            0.70 * feat["momentum_composite"] +
            0.30 * sent_norm
        ).clip(-1, 1)

        # Drop EMA columns from final output (they're intermediary)
        ema_cols = [c for c in feat.columns if c.startswith("ema_")]
        feat = feat.drop(columns=ema_cols)

        # Drop rows with too many NaNs (initial warmup period)
        feat = feat.dropna(thresh=len(feat.columns) // 2)

        logger.debug(f"{symbol}: {len(feat)} rows, {len(feat.columns)} features")
        return feat

    def get_feature_names(self) -> list:
        """Returns a predictable list of feature column names (for SHAP labels)."""
        return [
            "rsi_14", "rsi_9", "rsi_21",
            "macd", "macd_signal", "macd_hist",
            "roc_5", "roc_10", "roc_20",
            "williams_r", "stoch_k", "stoch_d",
            "price_vs_ema9", "price_vs_ema21", "price_vs_ema50", "price_vs_ema200",
            "golden_cross", "ema_slope_9",
            "atr_14", "atr_pct", "bb_width", "bb_pct",
            "hist_vol_10", "hist_vol_30", "vol_ratio",
            "vol_ratio_20", "obv", "obv_slope", "vol_zscore",
            "gap_up", "candle_body", "upper_wick", "lower_wick",
            "52w_high_ratio", "52w_low_ratio",
            "momentum_composite", "trend_regime", "vol_regime",
            "compound_score", "article_count", "alpha_signal",
        ]
