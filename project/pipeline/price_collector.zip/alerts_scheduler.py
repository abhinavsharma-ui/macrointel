"""
Alerts Scheduler & Production Logging
=======================================
Two responsibilities:

1. Production logging — structured JSON logs with rotation,
   called by run.py at startup.

2. Phone alerts via ntfy.sh — sends push notifications to your
   phone the instant a high-conviction signal fires.

ntfy.sh setup:
  1. Install the ntfy app on Android/iOS (free)
  2. Subscribe to your topic: open app → "+ Subscribe" → type NTFY_TOPIC
  3. Set env var: NTFY_TOPIC=macro-intel-alerts (or any unique string)
  4. Done — no account needed!

Alert priority mapping:
  conviction ≥ 8.5  → URGENT (phone rings)
  conviction ≥ 7.0  → HIGH (loud notification)
  conviction ≥ 5.0  → DEFAULT (silent notification)
  below 5.0         → no alert sent
"""

import json
import logging
import logging.handlers
import os
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

import requests

logger = logging.getLogger(__name__)

NTFY_BASE_URL = "https://ntfy.sh"
NTFY_TOPIC    = os.getenv("NTFY_TOPIC", "macro-intel-alerts")


# ─────────────────────────────────────────────────────────────
# Production logging setup
# ─────────────────────────────────────────────────────────────

class JSONFormatter(logging.Formatter):
    """Emit logs as structured JSON for easy parsing / log aggregators."""

    def format(self, record: logging.LogRecord) -> str:
        log_obj = {
            "timestamp": datetime.utcfromtimestamp(record.created).isoformat() + "Z",
            "level":     record.levelname,
            "logger":    record.name,
            "message":   record.getMessage(),
            "module":    record.module,
            "function":  record.funcName,
            "line":      record.lineno,
        }
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_obj, ensure_ascii=False)


def setup_production_logging(log_dir: str = "logs", level: int = logging.INFO):
    """
    Configure root logger for production:
      - Console  : human-readable (colored where available)
      - File     : JSON, rotated daily, kept 30 days
      - Error    : separate error-only file for quick incident review

    Call once from run.py before any other imports.
    """
    Path(log_dir).mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(level)

    # Clear any existing handlers (avoids duplicate output in Jupyter etc.)
    root.handlers.clear()

    # ── Console handler (human-readable) ──────────────────────
    console_fmt = logging.Formatter(
        "%(asctime)s  %(levelname)-8s  %(name)-30s  %(message)s",
        datefmt="%H:%M:%S",
    )
    console_h = logging.StreamHandler()
    console_h.setFormatter(console_fmt)
    console_h.setLevel(level)
    root.addHandler(console_h)

    # ── Rotating file handler (JSON) ──────────────────────────
    json_h = logging.handlers.TimedRotatingFileHandler(
        filename=os.path.join(log_dir, "system.jsonl"),
        when="midnight",
        backupCount=30,
        encoding="utf-8",
    )
    json_h.setFormatter(JSONFormatter())
    json_h.setLevel(level)
    root.addHandler(json_h)

    # ── Error-only file ───────────────────────────────────────
    err_h = logging.handlers.RotatingFileHandler(
        filename=os.path.join(log_dir, "errors.log"),
        maxBytes=10 * 1024 * 1024,  # 10 MB
        backupCount=5,
        encoding="utf-8",
    )
    err_h.setFormatter(console_fmt)
    err_h.setLevel(logging.ERROR)
    root.addHandler(err_h)

    # Suppress noisy third-party loggers
    for noisy in ["urllib3", "websocket", "engineio", "socketio", "werkzeug"]:
        logging.getLogger(noisy).setLevel(logging.WARNING)

    logger.info(f"Production logging configured (log_dir={log_dir!r})")


# ─────────────────────────────────────────────────────────────
# ntfy.sh alert sender
# ─────────────────────────────────────────────────────────────

class NtfyAlerter:
    """
    Sends push notifications to your phone via ntfy.sh.

    Usage:
        alerter = NtfyAlerter()
        alerter.send_signal_alert(signal_dict)
    """

    PRIORITY_MAP = {
        "urgent":  5,   # rings phone, vibrates
        "high":    4,   # loud notification
        "default": 3,   # normal
        "low":     2,   # silent
        "min":     1,   # barely visible
    }

    def __init__(self, topic: str = NTFY_TOPIC, base_url: str = NTFY_BASE_URL):
        self.topic   = topic
        self.base_url= base_url
        self._queue  = []
        self._lock   = threading.Lock()
        self._last_sent: Dict[str, float] = {}   # symbol → timestamp of last alert
        self._cooldown = 300                      # 5 min cooldown per symbol

    def _get_priority(self, conviction: float) -> str:
        if conviction >= 8.5:
            return "urgent"
        if conviction >= 7.0:
            return "high"
        return "default"

    def send(
        self,
        title: str,
        message: str,
        priority: str = "default",
        tags: Optional[list] = None,
        click_url: Optional[str] = None,
    ) -> bool:
        """Send a raw notification. Returns True if successful."""
        url = f"{self.base_url}/{self.topic}"
        headers = {
            "Title":    title,
            "Priority": str(self.PRIORITY_MAP.get(priority, 3)),
            "Content-Type": "text/plain; charset=utf-8",
        }
        if tags:
            headers["Tags"] = ",".join(tags)
        if click_url:
            headers["Click"] = click_url

        try:
            resp = requests.post(url, data=message.encode("utf-8"), headers=headers, timeout=5)
            resp.raise_for_status()
            logger.info(f"ntfy alert sent: {title!r} ({priority})")
            return True
        except Exception as e:
            logger.warning(f"ntfy send failed: {e}")
            return False

    def send_signal_alert(self, signal: Dict) -> bool:
        """
        Send a signal alert for a trading recommendation.
        Respects per-symbol cooldown to avoid notification spam.
        """
        symbol    = signal.get("symbol", "???")
        direction = signal.get("signal", "neutral").upper()
        conviction= float(signal.get("conviction_score", 0))
        confidence= float(signal.get("confidence", 0)) * 100

        # Don't alert on neutral or low-conviction signals
        if direction == "NEUTRAL" or conviction < 5.0:
            return False

        # Cooldown check
        with self._lock:
            last = self._last_sent.get(symbol, 0)
            if time.time() - last < self._cooldown:
                logger.debug(f"Alert suppressed for {symbol} (cooldown)")
                return False
            self._last_sent[symbol] = time.time()

        priority = self._get_priority(conviction)
        direction_emoji = "🟢" if direction == "BUY" else "🔴"
        tag_list = ["chart_increasing" if direction == "BUY" else "chart_decreasing", "moneybag"]

        title   = f"{direction_emoji} {direction} {symbol} — Conviction {conviction:.1f}/10"
        message = (
            f"Signal: {direction}\n"
            f"Symbol: {symbol}\n"
            f"Conviction: {conviction:.1f} / 10\n"
            f"Confidence: {confidence:.0f}%\n"
        )

        # Add risk parameters if available
        risk = signal.get("risk_parameters", {})
        if risk:
            sl  = risk.get("stop_loss_pct",  "—")
            tp  = risk.get("take_profit_pct","—")
            pos = risk.get("suggested_position_size_pct", "—")
            message += f"\nStop loss: {sl}%  |  Take profit: {tp}%\nPosition size: {pos}%"

        # Add top driver
        drivers = signal.get("top_drivers") or signal.get("waterfall_data") or []
        if drivers:
            top = drivers[0]
            message += f"\n\nTop driver: {top.get('label', top.get('feature', ''))}"

        return self.send(title, message, priority=priority, tags=tag_list)

    def send_camera_alert(
        self,
        person_id: str,
        is_new: bool,
        camera_url: Optional[str] = None,
    ) -> bool:
        """Send a security camera person-detection alert."""
        status = "NEW PERSON detected" if is_new else "Known person re-identified"
        icon   = "🚨" if is_new else "👤"
        title  = f"{icon} {status}"
        message= f"Person ID: {person_id}\nTime: {datetime.now().strftime('%H:%M:%S')}"
        if camera_url:
            message += f"\nView: {camera_url}"

        tags = ["warning"] if is_new else ["eyes"]
        return self.send(title, message, priority="high" if is_new else "default", tags=tags, click_url=camera_url)

    def send_system_status(self, message: str, is_error: bool = False) -> bool:
        """Send a system health notification."""
        title    = "⚠️ System Alert" if is_error else "ℹ️ System Status"
        priority = "high" if is_error else "low"
        tags     = ["warning"] if is_error else ["information_source"]
        return self.send(title, message, priority=priority, tags=tags)


# ─────────────────────────────────────────────────────────────
# Scheduled alert dispatcher (used by the inference loop)
# ─────────────────────────────────────────────────────────────

_global_alerter: Optional[NtfyAlerter] = None


def get_alerter() -> NtfyAlerter:
    """Return the singleton NtfyAlerter instance."""
    global _global_alerter
    if _global_alerter is None:
        _global_alerter = NtfyAlerter()
    return _global_alerter


def dispatch_signal_alerts(signal_store: Dict, min_conviction: float = 7.0):
    """
    Check signal store and fire phone alerts for high-conviction signals.
    Called by the inference loop after each update cycle.
    """
    alerter = get_alerter()
    fired   = 0
    for symbol, signal in signal_store.items():
        conviction = float(signal.get("conviction_score", 0))
        if conviction >= min_conviction:
            if alerter.send_signal_alert(signal):
                fired += 1
    if fired:
        logger.info(f"Fired {fired} phone alert(s)")
