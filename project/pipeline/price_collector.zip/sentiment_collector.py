"""
Sentiment Data Pipeline
========================
Collects and scores financial news sentiment using:
  Primary  — NewsAPI (api key needed for more than 100 requests/day)
  Fallback — RSS feeds (free, no key): Yahoo Finance, Reuters, Seeking Alpha
  Scoring  — VADER sentiment (NLTK, no model download needed)

Output:
    sentiment_results["symbol_sentiment_daily"]  — MultiIndex (symbol, date) DataFrame
    sentiment_results["headlines"]               — Raw headlines list
"""

import logging
import os
import time
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional

import pandas as pd
import requests

logger = logging.getLogger(__name__)

NEWS_API_KEY  = os.getenv("NEWS_API_KEY", "")
NEWS_API_BASE = "https://newsapi.org/v2/everything"

# ─────────────────────────────────────────────────────────────
# VADER sentiment scorer (free, rule-based, no GPU needed)
# ─────────────────────────────────────────────────────────────

def _get_vader():
    """Lazy-load VADER so the app doesn't crash if NLTK isn't installed."""
    try:
        from nltk.sentiment.vader import SentimentIntensityAnalyzer
        import nltk
        try:
            return SentimentIntensityAnalyzer()
        except LookupError:
            nltk.download("vader_lexicon", quiet=True)
            return SentimentIntensityAnalyzer()
    except ImportError:
        logger.warning("NLTK not installed. Run: pip install nltk. Returning neutral scorer.")
        return None


def score_text(text: str, vader=None) -> float:
    """
    Returns compound sentiment score in [-1, +1].
    Uses VADER if available, otherwise a simple keyword heuristic.
    """
    if vader is not None:
        return vader.polarity_scores(text)["compound"]

    # Simple keyword fallback
    positive = ["beat", "surge", "rally", "growth", "profit", "record", "upgrade", "bull"]
    negative = ["miss", "crash", "plunge", "loss", "downgrade", "layoff", "bear", "fraud"]
    text_l = text.lower()
    pos = sum(text_l.count(w) for w in positive)
    neg = sum(text_l.count(w) for w in negative)
    if pos + neg == 0:
        return 0.0
    return (pos - neg) / (pos + neg)


# ─────────────────────────────────────────────────────────────
# News fetchers
# ─────────────────────────────────────────────────────────────

class NewsAPIFetcher:
    """Fetches headlines from NewsAPI.org (requires API key)."""

    def __init__(self, api_key: str = NEWS_API_KEY):
        self.api_key = api_key
        self._last_call = 0.0

    def fetch(self, query: str, from_date: date, to_date: date) -> List[Dict]:
        if not self.api_key:
            return []

        elapsed = time.time() - self._last_call
        if elapsed < 1.0:
            time.sleep(1.0 - elapsed)
        self._last_call = time.time()

        params = {
            "q":         query,
            "from":      str(from_date),
            "to":        str(to_date),
            "language":  "en",
            "sortBy":    "publishedAt",
            "pageSize":  50,
            "apiKey":    self.api_key,
        }

        try:
            resp = requests.get(NEWS_API_BASE, params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            articles = data.get("articles", [])
            logger.debug(f"NewsAPI '{query}': {len(articles)} articles")
            return articles
        except Exception as e:
            logger.warning(f"NewsAPI error for '{query}': {e}")
            return []


class RSSFetcher:
    """
    Free RSS fallback — fetches from Yahoo Finance RSS feeds.
    No API key needed. Rate-limit friendly.
    """

    RSS_FEEDS = {
        "AAPL":       "https://feeds.finance.yahoo.com/rss/2.0/headline?s=AAPL&region=US&lang=en-US",
        "MSFT":       "https://feeds.finance.yahoo.com/rss/2.0/headline?s=MSFT&region=US&lang=en-US",
        "NVDA":       "https://feeds.finance.yahoo.com/rss/2.0/headline?s=NVDA&region=US&lang=en-US",
        "GOOGL":      "https://feeds.finance.yahoo.com/rss/2.0/headline?s=GOOGL&region=US&lang=en-US",
        "META":       "https://feeds.finance.yahoo.com/rss/2.0/headline?s=META&region=US&lang=en-US",
        "SPY":        "https://feeds.finance.yahoo.com/rss/2.0/headline?s=SPY&region=US&lang=en-US",
        "RELIANCE.NS":"https://feeds.finance.yahoo.com/rss/2.0/headline?s=RELIANCE.NS&region=IN&lang=en-US",
        "TCS.NS":     "https://feeds.finance.yahoo.com/rss/2.0/headline?s=TCS.NS&region=IN&lang=en-US",
        "INFY.NS":    "https://feeds.finance.yahoo.com/rss/2.0/headline?s=INFY.NS&region=IN&lang=en-US",
    }

    def fetch(self, symbol: str) -> List[Dict]:
        url = self.RSS_FEEDS.get(symbol)
        if not url:
            return []

        try:
            import xml.etree.ElementTree as ET
            resp = requests.get(url, timeout=8, headers={"User-Agent": "Mozilla/5.0"})
            root = ET.fromstring(resp.content)
            items = root.findall(".//item")
            articles = []
            for item in items[:20]:
                title   = item.findtext("title", "")
                pub_date= item.findtext("pubDate", "")
                articles.append({
                    "title":       title,
                    "description": title,
                    "publishedAt": pub_date,
                    "source":      "Yahoo Finance RSS",
                })
            logger.debug(f"RSS {symbol}: {len(articles)} headlines")
            return articles
        except Exception as e:
            logger.debug(f"RSS fetch failed for {symbol}: {e}")
            return []


# ─────────────────────────────────────────────────────────────
# Main pipeline
# ─────────────────────────────────────────────────────────────

class SentimentPipeline:
    """
    Collects news sentiment for a list of symbols.

    Usage:
        pipeline = SentimentPipeline()
        results  = pipeline.run(
            symbols=["AAPL", "MSFT", "NVDA"],
            days_back=3,
            save=True,
        )

    Result keys:
        symbol_sentiment_daily   — MultiIndex (symbol, date) DataFrame
        headlines                — {symbol: [list of article dicts]}
        run_timestamp            — ISO timestamp
    """

    def __init__(self):
        self.news_api = NewsAPIFetcher()
        self.rss      = RSSFetcher()
        self.vader    = _get_vader()

    def _score_articles(self, articles: List[Dict]) -> List[Dict]:
        """Score each article and extract the date."""
        scored = []
        for art in articles:
            text = f"{art.get('title', '')} {art.get('description', '') or ''}"
            try:
                pub = art.get("publishedAt", "")
                if isinstance(pub, str) and pub:
                    dt = pd.to_datetime(pub, utc=True).date()
                else:
                    dt = date.today()
            except Exception:
                dt = date.today()

            scored.append({
                "date":           dt,
                "title":          art.get("title", ""),
                "compound_score": score_text(text, self.vader),
                "source":         art.get("source", {}).get("name", "RSS") if isinstance(art.get("source"), dict) else art.get("source", "RSS"),
            })
        return scored

    def _fetch_symbol(self, symbol: str, from_date: date, to_date: date) -> List[Dict]:
        """Fetch articles for a symbol, trying NewsAPI then RSS."""
        # Clean symbol for search query
        query = symbol.replace(".NS", "").replace("SPY", "S&P 500 ETF")
        articles = self.news_api.fetch(query, from_date, to_date)

        if not articles:
            articles = self.rss.fetch(symbol)

        return self._score_articles(articles)

    def run(
        self,
        symbols: List[str],
        days_back: int = 3,
        save: bool = False,
    ) -> Dict:
        """Run full sentiment collection for all symbols."""
        logger.info(f"SentimentPipeline: {len(symbols)} symbols, last {days_back} days")

        to_date   = date.today()
        from_date = to_date - timedelta(days=days_back)

        all_headlines: Dict[str, List] = {}
        daily_records = []

        for symbol in symbols:
            try:
                articles = self._fetch_symbol(symbol, from_date, to_date)
                all_headlines[symbol] = articles

                for art in articles:
                    daily_records.append({
                        "symbol":         symbol,
                        "date":           art["date"],
                        "compound_score": art["compound_score"],
                        "article_count":  1,
                        "title":          art["title"],
                        "source":         art["source"],
                    })

                avg_score = sum(a["compound_score"] for a in articles) / max(len(articles), 1)
                logger.info(f"{symbol}: {len(articles)} articles, avg sentiment {avg_score:.3f}")

            except Exception as e:
                logger.error(f"Sentiment error for {symbol}: {e}")

        # Aggregate to daily level per symbol
        if daily_records:
            df = pd.DataFrame(daily_records)
            df["date"] = pd.to_datetime(df["date"])
            daily_agg = (
                df.groupby(["symbol", "date"])
                  .agg(
                      compound_score=("compound_score", "mean"),
                      article_count =("article_count",  "sum"),
                  )
                  .reset_index()
                  .set_index(["symbol", "date"])
            )
        else:
            daily_agg = pd.DataFrame(
                columns=["compound_score", "article_count"],
                index=pd.MultiIndex.from_tuples([], names=["symbol", "date"]),
            )

        result = {
            "symbol_sentiment_daily": daily_agg,
            "headlines":              all_headlines,
            "run_timestamp":          datetime.utcnow().isoformat(),
            "symbols_covered":        len(all_headlines),
        }

        logger.info(f"SentimentPipeline complete: {daily_agg.shape[0]} daily sentiment rows")
        return result
