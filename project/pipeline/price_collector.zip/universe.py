"""
Stock Universe
===============
500+ symbols across NSE (India) and NYSE/NASDAQ (US).
Organised by sector for sector-rotation analysis.

Usage:
    from pipeline.universe import NSE_SYMBOLS, US_SYMBOLS, ALL_SYMBOLS
    from pipeline.universe import get_sector, get_universe
"""

# ─────────────────────────────────────────────────────────────
# NSE Universe — 200 symbols
# ─────────────────────────────────────────────────────────────

NSE_LARGE_CAP = [
    # IT
    "TCS.NS", "INFY.NS", "WIPRO.NS", "HCLTECH.NS", "TECHM.NS",
    "LTIM.NS", "MPHASIS.NS", "COFORGE.NS", "PERSISTENT.NS", "OFSS.NS",
    # Banking & Finance
    "HDFCBANK.NS", "ICICIBANK.NS", "KOTAKBANK.NS", "AXISBANK.NS", "SBIN.NS",
    "INDUSINDBK.NS", "BANKBARODA.NS", "PNB.NS", "FEDERALBNK.NS", "IDFCFIRSTB.NS",
    "BAJFINANCE.NS", "BAJAJFINSV.NS", "CHOLAFIN.NS", "MUTHOOTFIN.NS", "SBICARD.NS",
    # Energy & Oil
    "RELIANCE.NS", "ONGC.NS", "IOC.NS", "BPCL.NS", "GAIL.NS",
    "POWERGRID.NS", "NTPC.NS", "ADANIGREEN.NS", "TATAPOWER.NS", "CESC.NS",
    # Auto
    "MARUTI.NS", "TATAMOTORS.NS", "M&M.NS", "BAJAJ-AUTO.NS", "HEROMOTOCO.NS",
    "EICHERMOT.NS", "ASHOKLEY.NS", "TVSMOTOR.NS", "BOSCHLTD.NS", "MOTHERSON.NS",
    # Pharma
    "SUNPHARMA.NS", "DRREDDY.NS", "CIPLA.NS", "DIVISLAB.NS", "BIOCON.NS",
    "LUPIN.NS", "AUROPHARMA.NS", "TORNTPHARM.NS", "ALKEM.NS", "IPCA.NS",
    # FMCG
    "HINDUNILVR.NS", "ITC.NS", "NESTLEIND.NS", "BRITANNIA.NS", "DABUR.NS",
    "MARICO.NS", "COLPAL.NS", "GODREJCP.NS", "EMAMILTD.NS", "VBL.NS",
    # Metals & Mining
    "TATASTEEL.NS", "JSWSTEEL.NS", "HINDALCO.NS", "VEDL.NS", "COALINDIA.NS",
    "NMDC.NS", "SAIL.NS", "HINDCOPPER.NS", "NATIONALUM.NS", "MOIL.NS",
    # Infrastructure & Real Estate
    "LARSEN.NS", "ULTRACEMCO.NS", "GRASIM.NS", "AMBUJACEM.NS", "ACC.NS",
    "DLF.NS", "GODREJPROP.NS", "OBEROIRLTY.NS", "PRESTIGE.NS", "PHOENIXLTD.NS",
    # Telecom & Media
    "BHARTIARTL.NS", "IDEA.NS", "TATACOMM.NS", "INDIAMART.NS", "ZOMATO.NS",
    # Consumer & Retail
    "TITAN.NS", "TRENT.NS", "DMART.NS", "NYKAA.NS", "PAYTM.NS",
    # Chemicals
    "PIDILITIND.NS", "SRF.NS", "DEEPAKNTR.NS", "AARTI.NS", "NAVINFLUOR.NS",
    # Insurance
    "HDFCLIFE.NS", "SBILIFE.NS", "ICICIlombard.NS", "ICICIPRULIFE.NS", "LICI.NS",
    # Aviation & Logistics
    "INDIGO.NS", "DELHIVERY.NS", "CONCOR.NS", "BLUEDART.NS", "GESHIP.NS",
]

NSE_MID_CAP = [
    "IRCTC.NS", "POLYCAB.NS", "DIXON.NS", "KALYANKJIL.NS", "SAPPHIRE.NS",
    "KPITTECH.NS", "TATAELXSI.NS", "LTTS.NS", "CYIENT.NS", "RATEGAIN.NS",
    "ANGELONE.NS", "BSE.NS", "CAMS.NS", "CDSL.NS", "MCX.NS",
    "AARTIIND.NS", "CLEAN.NS", "LAXMIMACH.NS", "GRINDWELL.NS", "SCHAEFFLER.NS",
    "ABFRL.NS", "PAGEIND.NS", "MANYAVAR.NS", "VEDANT.NS", "SHOPERSTOP.NS",
    "METROPOLIS.NS", "DRLALPATH.NS", "THYROCARE.NS", "VIJAYABANK.NS", "EQUITASBNK.NS",
]

NSE_SYMBOLS = NSE_LARGE_CAP + NSE_MID_CAP


# ─────────────────────────────────────────────────────────────
# US Universe — 300 symbols
# ─────────────────────────────────────────────────────────────

US_MEGA_CAP = [
    # Tech
    "AAPL", "MSFT", "NVDA", "GOOGL", "META", "AMZN", "TSLA", "AVGO", "ORCL", "AMD",
    "INTC", "QCOM", "TXN", "MU", "AMAT", "LRCX", "KLAC", "MRVL", "NXPI", "ON",
    # Finance
    "JPM", "BAC", "WFC", "GS", "MS", "BLK", "C", "AXP", "COF", "USB",
    "V", "MA", "PYPL", "SQ", "COIN", "SCHW", "HOOD", "IBKR", "ICE", "CME",
    # Healthcare
    "JNJ", "UNH", "PFE", "ABBV", "MRK", "LLY", "BMY", "AMGN", "GILD", "BIIB",
    "ISRG", "SYK", "BSX", "EW", "MDT", "ZBH", "HOLX", "DXCM", "PODD", "TDOC",
    # Consumer
    "AMZN", "WMT", "TGT", "COST", "HD", "LOW", "MCD", "SBUX", "NKE", "LULU",
    "TJX", "ROST", "DG", "DLTR", "KR", "SFM", "ULTA", "FIVE", "BJ", "OLLI",
    # Energy
    "XOM", "CVX", "COP", "EOG", "PXD", "MPC", "VLO", "PSX", "OXY", "SLB",
    "HAL", "BKR", "DVN", "FANG", "APA", "MRO", "HES", "CTRA", "PR", "SM",
    # Industrial
    "CAT", "DE", "HON", "GE", "RTX", "LMT", "NOC", "BA", "GD", "LHX",
    "UPS", "FDX", "CSX", "UNP", "NSC", "DAL", "UAL", "AAL", "LUV", "ALK",
    # ETFs (for macro signals)
    "SPY", "QQQ", "IWM", "DIA", "VTI", "GLD", "SLV", "TLT", "HYG", "VIX",
    # Communication
    "NFLX", "DIS", "CMCSA", "T", "VZ", "TMUS", "CHTR", "PARA", "WBD", "FOXA",
    # Real Estate
    "AMT", "PLD", "EQIX", "CCI", "SPG", "O", "PSA", "EQR", "AVB", "DRE",
    # Utilities
    "NEE", "DUK", "SO", "D", "AEP", "EXC", "SRE", "PCG", "ES", "ETR",
    # New Tech / AI plays
    "PLTR", "AI", "SNOW", "DDOG", "NET", "ZS", "CRWD", "PANW", "S", "FTNT",
    "NOW", "CRM", "WDAY", "ADSK", "TEAM", "HUBS", "VEEV", "DOCU", "ZM", "OKTA",
    "UBER", "LYFT", "ABNB", "DASH", "RBLX", "SNAP", "PINS", "SPOT", "MTCH", "IAC",
]

US_SYMBOLS = list(dict.fromkeys(US_MEGA_CAP))   # deduplicate preserving order

# ─────────────────────────────────────────────────────────────
# Combined universe
# ─────────────────────────────────────────────────────────────

ALL_SYMBOLS = US_SYMBOLS + NSE_SYMBOLS

# Smaller curated list for fast startup / testing
CORE_US_SYMBOLS = [
    "AAPL", "MSFT", "NVDA", "GOOGL", "META", "AMZN", "TSLA",
    "JPM", "BAC", "V", "MA", "UNH", "JNJ", "XOM", "CVX",
    "SPY", "QQQ", "GLD", "TLT",
]

CORE_NSE_SYMBOLS = [
    "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS",
    "HINDUNILVR.NS", "BAJFINANCE.NS", "MARUTI.NS", "SUNPHARMA.NS", "TATAMOTORS.NS",
    "BHARTIARTL.NS", "KOTAKBANK.NS", "WIPRO.NS", "AXISBANK.NS", "ITC.NS",
]

CORE_SYMBOLS = CORE_US_SYMBOLS + CORE_NSE_SYMBOLS

# ─────────────────────────────────────────────────────────────
# Sector mapping
# ─────────────────────────────────────────────────────────────

SECTOR_MAP = {
    # US sectors
    "AAPL":"Technology","MSFT":"Technology","NVDA":"Technology","GOOGL":"Technology",
    "META":"Technology","AMZN":"Consumer","TSLA":"Auto","AVGO":"Technology",
    "AMD":"Technology","INTC":"Technology","QCOM":"Technology",
    "JPM":"Finance","BAC":"Finance","WFC":"Finance","GS":"Finance","MS":"Finance",
    "V":"Finance","MA":"Finance","PYPL":"Finance","BLK":"Finance",
    "JNJ":"Healthcare","UNH":"Healthcare","PFE":"Healthcare","ABBV":"Healthcare",
    "MRK":"Healthcare","LLY":"Healthcare","AMGN":"Healthcare","GILD":"Healthcare",
    "XOM":"Energy","CVX":"Energy","COP":"Energy","EOG":"Energy","SLB":"Energy",
    "SPY":"ETF","QQQ":"ETF","GLD":"ETF","TLT":"ETF","IWM":"ETF",
    "CAT":"Industrial","DE":"Industrial","HON":"Industrial","GE":"Industrial",
    "NEE":"Utilities","DUK":"Utilities","SO":"Utilities",
    "PLTR":"Technology","SNOW":"Technology","CRWD":"Technology","NET":"Technology",
    # NSE sectors
    "TCS.NS":"IT","INFY.NS":"IT","WIPRO.NS":"IT","HCLTECH.NS":"IT","TECHM.NS":"IT",
    "HDFCBANK.NS":"Banking","ICICIBANK.NS":"Banking","KOTAKBANK.NS":"Banking",
    "AXISBANK.NS":"Banking","SBIN.NS":"Banking","BAJFINANCE.NS":"Finance",
    "RELIANCE.NS":"Energy","ONGC.NS":"Energy","IOC.NS":"Energy","BPCL.NS":"Energy",
    "HINDUNILVR.NS":"FMCG","ITC.NS":"FMCG","NESTLEIND.NS":"FMCG",
    "SUNPHARMA.NS":"Pharma","DRREDDY.NS":"Pharma","CIPLA.NS":"Pharma",
    "TATASTEEL.NS":"Metals","JSWSTEEL.NS":"Metals","HINDALCO.NS":"Metals",
    "MARUTI.NS":"Auto","TATAMOTORS.NS":"Auto","M&M.NS":"Auto",
    "BHARTIARTL.NS":"Telecom","ZOMATO.NS":"Consumer","TITAN.NS":"Consumer",
    "LARSEN.NS":"Infrastructure","ULTRACEMCO.NS":"Infrastructure",
}


def get_sector(symbol: str) -> str:
    return SECTOR_MAP.get(symbol, "Other")


def get_universe(mode: str = "core") -> list:
    """
    mode: 'core'  — 35 key symbols (fast, good for testing)
          'full'  — 500+ symbols (slow first fetch, best signals)
          'us'    — US only
          'nse'   — NSE only
    """
    if mode == "core":   return CORE_SYMBOLS
    if mode == "full":   return ALL_SYMBOLS
    if mode == "us":     return US_SYMBOLS
    if mode == "nse":    return NSE_SYMBOLS
    return CORE_SYMBOLS
