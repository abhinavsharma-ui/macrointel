"""
Price Data Pipeline
====================
Fetches OHLCV price data from:
  Primary  — Alpha Vantage (daily adjusted, intraday)
  Fallback — yfinance (free, no API key needed)
"""

import logging
import os
import time
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional

import pandas as pd
import requests

logger = logging.getLogger(__name__)

AV_BASE = "https://www.alphavantage.co/query"
AV_KEY  = os.getenv("ALPHA_VANTAGE_API_KEY", "")

US_SYMBOLS = [
    # Tech
    "AAPL", "MSFT", "NVDA", "GOOGL", "META", "AMZN", "TSLA", "AMD", "INTC", "CRM",
    "ORCL", "ADBE", "QCOM", "NFLX", "UBER",
    # Finance
    "JPM", "BAC", "GS", "V", "MA", "BRK-B", "MS", "C",
    # ETFs
    "SPY", "QQQ", "IWM", "DIA", "XLF",
    # Healthcare
    "JNJ", "PFE", "UNH", "ABBV", "MRK",
    # High volatility/growth
    "PLTR", "COIN", "RBLX", "HOOD", "RIVN", "MSTR", "SOFI"
]

ALL_SYMBOLS = US_SYMBOLS


class AlphaVantageFetcher:
    def __init__(self, api_key: str = AV_KEY):
        self.api_key = api_key
        self._last_call = 0.0
        self._rate_limit_sec = 12.5

    def _throttle(self):
        elapsed = time.time() - self._last_call
        if elapsed < self._rate_limit_sec:
            time.sleep(self._rate_limit_sec - elapsed)
        self._last_call = time.time()

    def fetch_daily(self, symbol: str, full: bool = False) -> Optional[pd.DataFrame]:
        if not self.api_key:
            return None
        self._throttle()
        params = {
            "function": "TIME_SERIES_DAILY_ADJUSTED",
            "symbol": symbol,
            "outputsize": "full" if full else "compact",
            "apikey": self.api_key,
        }
        try:
            resp = requests.get(AV_BASE, params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
            if "Time Series (Daily)" not in data:
                err = data.get("Note") or data.get("Information") or "Unknown error"
                logger.warning(f"Alpha Vantage {symbol}: {err[:100]}")
                return None
            ts = data["Time Series (Daily)"]
            records = []
            for dt_str, vals in ts.items():
                records.append({
                    "date":      pd.Timestamp(dt_str),
                    "open":      float(vals["1. open"]),
                    "high":      float(vals["2. high"]),
                    "low":       float(vals["3. low"]),
                    "close":     float(vals["4. close"]),
                    "adj_close": float(vals["5. adjusted close"]),
                    "volume":    int(vals["6. volume"]),
                })
            df = pd.DataFrame(records).set_index("date").sort_index()
            return df
        except Exception as e:
            logger.error(f"AlphaVantage fetch error for {symbol}: {e}")
            return None


class YFinanceFetcher:
    def fetch_daily(self, symbol: str, start: Optional[date] = None, end: Optional[date] = None) -> Optional[pd.DataFrame]:
        try:
            import yfinance as yf
            start = start or (date.today() - timedelta(days=365 * 3))
            end   = end   or date.today()
            ticker = yf.Ticker(symbol)
            raw = ticker.history(start=str(start), end=str(end), auto_adjust=True)
            if raw.empty:
                return None
            df = raw[["Open", "High", "Low", "Close", "Volume"]].copy()
            df.columns = ["open", "high", "low", "close", "volume"]
            df["adj_close"] = df["close"]
            df.index = pd.to_datetime(df.index).tz_localize(None)
            df.index.name = "date"
            return df.sort_index()
        except Exception as e:
            logger.error(f"yfinance fetch error for {symbol}: {e}")
            return None


class PriceDataPipeline:
    def __init__(self, symbols: Optional[List[str]] = None):
        self.symbols = symbols or ALL_SYMBOLS
        self.av = AlphaVantageFetcher()
        self.yf = YFinanceFetcher()
        self._cache: Dict[str, pd.DataFrame] = {}

    def _fetch_symbol(self, symbol: str) -> Optional[pd.DataFrame]:
        if AV_KEY:
            df = self.av.fetch_daily(symbol)
            if df is not None and not df.empty:
                return df
        return self.yf.fetch_daily(symbol)

    def run_incremental_update(self) -> Dict:
        logger.info(f"PriceDataPipeline: fetching {len(self.symbols)} symbols...")
        errors = []
        price_daily_recent = {}
        price_daily_full = {}
        cutoff = pd.Timestamp(date.today() - timedelta(days=365))

        for i, symbol in enumerate(self.symbols):
            try:
                df = self._fetch_symbol(symbol)
                if df is None or df.empty:
                    errors.append(symbol)
                    continue
                required = {"open", "high", "low", "close", "volume"}
                if not required.issubset(df.columns):
                    errors.append(symbol)
                    continue
                df = df.dropna(subset=["close", "volume"])
                price_daily_full[symbol] = df
                price_daily_recent[symbol] = df[df.index >= cutoff].copy()
                self._cache[symbol] = df
                logger.info(f"[{i+1}/{len(self.symbols)}] {symbol}: {len(df)} rows OK")
            except Exception as e:
                logger.error(f"Pipeline error for {symbol}: {e}")
                errors.append(symbol)

        result = {
            "price_daily_recent": price_daily_recent,
            "price_daily_full":   price_daily_full,
            "fetch_errors":       errors,
            "symbols_ok":         len(price_daily_recent),
            "run_timestamp":      datetime.utcnow().isoformat(),
        }
        logger.info(f"PriceDataPipeline complete: {result['symbols_ok']}/{len(self.symbols)} symbols OK, {len(errors)} errors")
        return result

    def get_latest_close(self, symbol: str) -> Optional[float]:
        df = self._cache.get(symbol)
        if df is not None and not df.empty:
            return float(df["close"].iloc[-1])
        return None
