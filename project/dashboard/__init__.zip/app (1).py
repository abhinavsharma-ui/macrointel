"""
Flask-SocketIO Dashboard — Fully Wired
========================================
This is the production version. Zero demo mode.

Every API route returns real data:
  /api/signals      → live signals from signal_engine_v2 (MultiFactorScorer)
  /api/portfolio    → live paper broker P&L and positions
  /api/stress-test  → regime-aware stress test results
  /api/prices       → latest tick per symbol from price buffer
  /api/latency      → WebSocket latency stats
  /api/positions    → open positions with current P&L
  /api/diagnostics  → signal quality report (detects 38%-win-rate problems)

SocketIO push (1 Hz):
  prices_update     → latest price per active symbol
  new_signal        → fired immediately when a new signal is generated
  portfolio_update  → P&L, cash, drawdown after every price tick
  latency_update    → latency stats every 10s

Standalone launch:
  python dashboard/app.py
  Boots the FULL system: data pipeline + signal engine + paper broker + dashboard.
  Not demo mode. Requires API keys in .env or environment.
"""

import logging
import os
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

ROOT = Path(__file__).parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flask import Flask, jsonify, render_template_string
from flask_cors import CORS
from flask_socketio import SocketIO, emit

logger = logging.getLogger(__name__)
_startup_time = time.time()


# ─────────────────────────────────────────────────────────────
# App factory
# ─────────────────────────────────────────────────────────────
def create_app(
    price_buffer=None,
    paper_broker=None,
    signal_store: Optional[Dict] = None,
    stress_results: Optional[Dict] = None,
    latency_monitor=None,
    security_suite=None,
) -> tuple:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "macro-intel-prod-2024")
    CORS(app)
    socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading",
                        logger=False, engineio_logger=False)

    _signal_store   = signal_store   if signal_store   is not None else {}
    _stress_results = stress_results if stress_results is not None else {}
    _client_count   = [0]

    # ── REST ─────────────────────────────────────────────────

    @app.route("/")
    def index():
        return render_template_string(DASHBOARD_HTML)

    @app.route("/api/signals")
    def get_signals():
        sigs = list(_signal_store.values())
        sigs.sort(key=lambda s: (
            0 if s.get("signal") == "buy" else 1 if s.get("signal") == "sell" else 2,
            -(s.get("confidence") or 0),
        ))
        return jsonify({
            "signals":    sigs,
            "count":      len(sigs),
            "buy_count":  sum(1 for s in sigs if s.get("signal") == "buy"),
            "sell_count": sum(1 for s in sigs if s.get("signal") == "sell"),
            "hold_count": sum(1 for s in sigs if s.get("signal") == "neutral"),
            "timestamp":  datetime.now(timezone.utc).isoformat(),
        })

    @app.route("/api/signals/<symbol>")
    def get_signal(symbol):
        sig = _signal_store.get(symbol.upper())
        if not sig:
            return jsonify({"error": f"No signal for {symbol}"}), 404
        return jsonify(sig)

    @app.route("/api/prices")
    def get_prices():
        if price_buffer is None:
            return jsonify({"prices": {}, "note": "price_buffer not connected"})
        prices = {}
        for sym in price_buffer.active_symbols():
            tick = price_buffer.latest(sym)
            if not tick:
                continue
            recent = price_buffer.recent_ticks(sym, n=60)
            prev = recent[0].price if len(recent) > 1 else tick.price
            chg = round((tick.price / prev - 1) * 100, 3) if prev else 0
            prices[sym] = {
                "price":      round(tick.price, 4),
                "volume":     tick.volume,
                "market":     tick.market,
                "change_pct": chg,
                "direction":  "up" if chg > 0 else "down" if chg < 0 else "flat",
                "timestamp":  tick.timestamp.isoformat(),
            }
        return jsonify({"prices": prices, "active_count": len(prices),
                        "timestamp": datetime.now(timezone.utc).isoformat()})

    @app.route("/api/portfolio")
    def get_portfolio():
        if paper_broker is None:
            return jsonify({"initial_capital": 100000, "current_portfolio_value": 100000,
                            "total_return_pct": 0, "cash": 100000, "open_positions": 0,
                            "total_trades": 0, "win_rate_pct": 0, "kill_switch_active": False,
                            "positions": {}, "note": "paper_broker not connected"})
        return jsonify(paper_broker.get_summary())

    @app.route("/api/positions")
    def get_positions():
        if paper_broker is None:
            return jsonify({"positions": []})
        summary = paper_broker.get_summary()
        positions = []
        for sym, pos in (summary.get("positions") or {}).items():
            entry = dict(pos)
            entry["symbol"] = sym
            if price_buffer:
                tick = price_buffer.latest(sym)
                if tick:
                    entry["current_price"] = round(tick.price, 4)
                    entry["unrealized_pnl"] = round(
                        (tick.price - pos.get("avg_cost", tick.price)) * pos.get("quantity", 0), 2
                    )
            positions.append(entry)
        positions.sort(key=lambda p: abs(p.get("unrealized_pnl", 0)), reverse=True)
        return jsonify({"positions": positions, "count": len(positions)})

    @app.route("/api/stress-test")
    def get_stress_test():
        if not _stress_results:
            return jsonify({"_note": "Computing... check back in ~30s"})
        return jsonify(_stress_results)

    @app.route("/api/latency")
    def get_latency():
        if latency_monitor is None:
            return jsonify({"note": "latency_monitor not connected"})
        return jsonify(latency_monitor.stats)

    @app.route("/api/diagnostics")
    def get_diagnostics():
        if not _signal_store:
            return jsonify({"error": "No signals yet",
                            "hint": "Wait ~5 min for first inference cycle"})
        sigs = list(_signal_store.values())
        directions = [s.get("signal", "neutral") for s in sigs]
        confidences = [s.get("confidence", 0) for s in sigs]
        regimes = [s.get("regime", "unknown") for s in sigs]
        factor_scores = [s.get("factor_scores", {}) for s in sigs if s.get("factor_scores")]

        diag = {
            "total_signals":   len(sigs),
            "distribution":    {"buy": directions.count("buy"), "sell": directions.count("sell"),
                                "neutral": directions.count("neutral")},
            "buy_pct":         round(directions.count("buy") / max(len(directions), 1) * 100, 1),
            "sell_pct":        round(directions.count("sell") / max(len(directions), 1) * 100, 1),
            "avg_confidence":  round(sum(confidences) / max(len(confidences), 1), 3),
            "regime_counts":   {r: regimes.count(r) for r in set(regimes)},
        }

        if factor_scores:
            import numpy as np
            for factor in ["trend", "momentum", "mean_revert", "volume", "sentiment"]:
                vals = [fs.get(factor, 0) for fs in factor_scores]
                diag[f"avg_{factor}_score"] = round(float(np.mean(vals)), 4)

        issues = []
        if diag["sell_pct"] > diag["buy_pct"] * 3:
            issues.append("SELL BIAS: sell signals 3x buys. Check RSI scoring in signal_engine_v2.py")
        if diag["buy_pct"] + diag["sell_pct"] < 10:
            issues.append("TOO FEW SIGNALS: <10% actionable. Data may be stale.")
        if diag["avg_confidence"] < 0.15:
            issues.append("LOW CONFIDENCE: scores near zero. Check feature normalization.")
        if not issues:
            issues.append("OK: Signal distribution looks healthy.")
        diag["issues"] = issues
        diag["checked_at"] = datetime.now(timezone.utc).isoformat()
        return jsonify(diag)

    @app.route("/api/health")
    def health():
        buf = price_buffer.stats if price_buffer else {}
        return jsonify({
            "status":           "ok",
            "tick_count":       buf.get("total_ticks", 0),
            "active_symbols":   len(price_buffer.active_symbols()) if price_buffer else 0,
            "signal_count":     len(_signal_store),
            "broker_connected": paper_broker is not None,
            "stress_computed":  bool(_stress_results),
            "uptime_seconds":   round(time.time() - _startup_time),
            "timestamp":        datetime.now(timezone.utc).isoformat(),
        })

    # ── SocketIO events ───────────────────────────────────────

    @socketio.on("connect")
    def handle_connect():
        _client_count[0] += 1
        logger.debug(f"Client connected [{_client_count[0]}]")
        if _signal_store:
            emit("signals_update", {"signals": list(_signal_store.values())[:50]})
        if paper_broker:
            emit("portfolio_update", paper_broker.get_summary())
        if _stress_results:
            emit("stress_update", _stress_results)

    @socketio.on("disconnect")
    def handle_disconnect():
        _client_count[0] = max(0, _client_count[0] - 1)

    @socketio.on("subscribe_symbol")
    def handle_subscribe(data):
        sym = (data.get("symbol") or "").upper()
        if sym and price_buffer:
            tick = price_buffer.latest(sym)
            if tick:
                emit("price_update", {"symbol": sym, "price": tick.price,
                                      "market": tick.market,
                                      "timestamp": tick.timestamp.isoformat()})
        sig = _signal_store.get(sym)
        if sig:
            emit("signal_detail", sig)

    # ── Push thread ───────────────────────────────────────────

    _last_ids = set()
    _last_lat_push = [0.0]

    def _push_loop():
        while True:
            try:
                if _client_count[0] == 0:
                    time.sleep(0.5)
                    continue

                # Prices
                if price_buffer:
                    prices = {}
                    for sym in list(price_buffer.active_symbols())[:50]:
                        tick = price_buffer.latest(sym)
                        if not tick:
                            continue
                        recent = price_buffer.recent_ticks(sym, n=10)
                        prev = recent[0].price if len(recent) > 1 else tick.price
                        chg = round((tick.price / prev - 1) * 100, 3) if prev else 0
                        prices[sym] = {"price": round(tick.price, 4), "change_pct": chg,
                                       "market": tick.market,
                                       "direction": "up" if chg > 0 else "down" if chg < 0 else "flat"}
                    if prices:
                        socketio.emit("prices_update", {"prices": prices})

                # Signals
                cur_ids = set(_signal_store.keys())
                new_ids = cur_ids - _last_ids
                for sid in new_ids:
                    sig = _signal_store.get(sid)
                    if sig:
                        socketio.emit("new_signal", sig)
                _last_ids.update(new_ids)
                if cur_ids:
                    socketio.emit("signals_update", {"signals": list(_signal_store.values())[:50]})

                # Portfolio
                if paper_broker:
                    socketio.emit("portfolio_update", paper_broker.get_summary())

                # Latency
                now = time.time()
                if latency_monitor and now - _last_lat_push[0] > 10:
                    socketio.emit("latency_update", latency_monitor.stats)
                    _last_lat_push[0] = now

            except Exception as exc:
                logger.debug(f"Push loop: {exc}")

            time.sleep(1)

    threading.Thread(target=_push_loop, daemon=True, name="push").start()
    return app, socketio


# ─────────────────────────────────────────────────────────────
# Dashboard HTML
# ─────────────────────────────────────────────────────────────
DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MacroIntel Live</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.6.0/socket.io.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600&family=Syne:wght@700;800&display=swap" rel="stylesheet">
<style>
:root{--bg:#090d13;--bg2:#0f141d;--bg3:#161d28;--bg4:#1d2535;--border:rgba(255,255,255,0.06);--border2:rgba(255,255,255,0.11);--text:#dde3ef;--muted:#5a6478;--faint:#333d52;--green:#22c55e;--red:#ef4444;--amber:#f59e0b;--blue:#3b82f6;--purple:#a78bfa;--mono:'JetBrains Mono',monospace;--sans:'Syne',sans-serif;}
*{box-sizing:border-box;margin:0;padding:0;}
body{background:var(--bg);color:var(--text);font-family:var(--mono);font-size:13px;min-height:100vh;}
.topbar{display:flex;align-items:center;justify-content:space-between;padding:10px 20px;background:var(--bg2);border-bottom:1px solid var(--border);height:48px;}
.logo{font-family:var(--sans);font-size:17px;font-weight:800;letter-spacing:-.5px;}
.logo em{color:var(--blue);font-style:normal;}
.dot{width:7px;height:7px;border-radius:50%;background:var(--red);animation:blink 2s infinite;}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
.tr{display:flex;gap:20px;font-size:11px;}.tr span{color:var(--muted);}.tr strong{color:var(--text);}
.sbar{display:flex;gap:16px;padding:5px 20px;background:var(--bg2);border-bottom:1px solid var(--border);font-size:10px;color:var(--muted);}
.layout{display:grid;grid-template-columns:276px 1fr;height:calc(100vh - 80px);}
.sidebar{background:var(--bg2);border-right:1px solid var(--border);overflow-y:auto;}
.sbh{padding:10px 14px;font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;}
.sbh button{font-size:9px;background:none;border:1px solid var(--border2);color:var(--muted);padding:2px 8px;border-radius:3px;cursor:pointer;font-family:var(--mono);}
.si{padding:10px 14px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .1s;}
.si:hover{background:var(--bg3);}
.si.active{background:rgba(59,130,246,.07);border-left:2px solid var(--blue);padding-left:12px;}
.sr{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;}
.ssym{font-weight:600;font-size:12px;}
.badge{font-size:9px;padding:1px 6px;border-radius:3px;font-weight:600;text-transform:uppercase;}
.b-buy{background:rgba(34,197,94,.14);color:var(--green);}
.b-sell{background:rgba(239,68,68,.14);color:var(--red);}
.b-neutral{background:rgba(90,100,120,.2);color:var(--muted);}
.smeta{font-size:10px;color:var(--muted);display:flex;gap:8px;}
.ct{height:2px;background:var(--faint);border-radius:1px;margin-top:6px;}
.cf{height:100%;border-radius:1px;transition:width .4s;}
.content{overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:12px;}
.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;}
.met{background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:11px 13px;}
.ml{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:6px;}
.mv{font-size:20px;font-weight:700;font-family:var(--sans);}
.ms{font-size:10px;color:var(--muted);margin-top:2px;}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:7px;padding:14px;}
.ct2{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-bottom:12px;}
.dg{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.wr{display:flex;align-items:center;gap:7px;margin-bottom:4px;}
.wl{width:150px;font-size:10px;color:var(--muted);text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.wt{flex:1;height:16px;background:var(--bg3);border-radius:2px;position:relative;overflow:hidden;}
.wp{position:absolute;left:0;top:0;height:100%;background:rgba(34,197,94,.2);color:var(--green);font-size:9px;display:flex;align-items:center;padding-left:3px;}
.wn{position:absolute;right:0;top:0;height:100%;background:rgba(239,68,68,.18);color:var(--red);font-size:9px;display:flex;align-items:center;justify-content:flex-end;padding-right:3px;}
.fr{display:flex;align-items:center;gap:5px;margin-bottom:3px;}
.fn{width:74px;font-size:10px;color:var(--muted);}
.fb{flex:1;height:5px;background:var(--faint);border-radius:3px;overflow:hidden;}
.ff{height:100%;border-radius:3px;transition:width .4s;}
.fv{width:44px;text-align:right;font-size:10px;}
.fw{width:22px;font-size:9px;color:var(--faint);}
.rg{display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:7px;}
.ri{background:var(--bg3);border-radius:4px;padding:7px 9px;}
.rl{font-size:9px;color:var(--muted);margin-bottom:2px;}
.rv{font-size:11px;font-weight:500;}
.rp{display:inline-block;font-size:10px;padding:2px 7px;border-radius:4px;border:1px solid var(--border2);margin:2px;}
.cfb{background:rgba(167,139,250,.07);border:1px solid rgba(167,139,250,.18);border-radius:5px;padding:9px 11px;font-size:10px;color:var(--purple);line-height:1.6;margin-top:9px;}
.wb{background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.2);border-radius:5px;padding:7px 11px;font-size:10px;color:var(--amber);margin-top:5px;}
.sg{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;}
.sc{background:var(--bg3);border-radius:5px;padding:9px 11px;border-left:2px solid var(--faint);}
.sc.pass{border-left-color:var(--green);}
.sc.fail{border-left-color:var(--red);}
.sn{font-size:9px;color:var(--muted);margin-bottom:4px;}
.sd{font-size:13px;font-weight:600;}
.sm{font-size:9px;color:var(--muted);margin-top:2px;}
.pt{width:100%;border-collapse:collapse;font-size:11px;}
.pt th{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.4px;padding:5px 7px;text-align:left;border-bottom:1px solid var(--border);}
.pt td{padding:6px 7px;border-bottom:1px solid var(--border);}
.pt tr:last-child td{border-bottom:none;}
.pt tr:hover td{background:var(--bg3);}
.cw{position:relative;height:150px;}
::-webkit-scrollbar{width:3px;height:3px;}
::-webkit-scrollbar-thumb{background:var(--faint);border-radius:2px;}
.up{color:var(--green);}.dn{color:var(--red);}.fl{color:var(--muted);}
.empty{padding:18px;color:var(--muted);font-size:10px;text-align:center;}
</style>
</head>
<body>
<div class="topbar">
  <div style="display:flex;align-items:center;gap:10px">
    <div class="dot" id="cdot"></div>
    <div class="logo">Macro<em>Intel</em></div>
    <div style="font-size:10px;color:var(--muted)">live trading intelligence</div>
  </div>
  <div class="tr">
    <span>Symbols <strong id="hs">—</strong></span>
    <span>Signals <strong id="hsi">—</strong></span>
    <span>Portfolio <strong id="hp" class="up">—</strong></span>
    <span>Last tick <strong id="ht">—</strong></span>
    <span>Uptime <strong id="hu">—</strong></span>
  </div>
</div>
<div class="sbar">
  <span>WS avg: <strong id="sl" style="color:var(--muted)">—</strong> ms</span>
  <span>p95: <strong id="sp">—</strong> ms</span>
  <span id="scl" style="color:var(--red)">Disconnected</span>
  <span style="margin-left:auto">
    <button onclick="fetch('/api/diagnostics').then(r=>r.json()).then(d=>alert(JSON.stringify(d.issues||d,null,2)))"
      style="background:none;border:1px solid var(--border2);color:var(--muted);padding:1px 7px;border-radius:3px;cursor:pointer;font-family:var(--mono);font-size:9px">
      run diagnostics
    </button>
  </span>
</div>
<div class="layout">
  <div class="sidebar">
    <div class="sbh"><span>Live Signals</span><button onclick="sd='symbol'===sd?'confidence':'symbol'">sort</button></div>
    <div id="slist"><div class="empty">Connecting...</div></div>
  </div>
  <div class="content">
    <div class="metrics">
      <div class="met"><div class="ml">Portfolio value</div><div class="mv up" id="mpv">$100,000</div><div class="ms" id="mret">+0.00%</div></div>
      <div class="met"><div class="ml">Today's signals</div><div class="mv" style="color:var(--blue)" id="mns">0</div><div class="ms" id="msp">0 buy · 0 sell · 0 hold</div></div>
      <div class="met"><div class="ml">Win rate (paper)</div><div class="mv" id="mwr">—</div><div class="ms">30-day rolling</div></div>
      <div class="met"><div class="ml">Stress grade</div><div class="mv" style="color:var(--amber)" id="msg">—</div><div class="ms" id="msgs">black swan score</div></div>
    </div>
    <div class="card">
      <div class="ct2">Signal intelligence — <span id="dsym" style="color:var(--blue)">select a signal</span></div>
      <div class="dg">
        <div>
          <div style="font-size:9px;color:var(--muted);margin-bottom:8px">Feature contributions (SHAP)</div>
          <div id="dwf"><div class="empty" style="padding:10px">No signal selected</div></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          <div>
            <div style="font-size:9px;color:var(--muted);margin-bottom:6px">Conviction score</div>
            <div style="display:flex;align-items:baseline;gap:6px">
              <span id="dconv" style="font-size:28px;font-weight:700;font-family:var(--sans)">—</span>
              <span style="font-size:10px;color:var(--muted)">/ 10</span>
              <span id="dconf" style="font-size:10px;color:var(--muted)"></span>
            </div>
          </div>
          <div>
            <div style="font-size:9px;color:var(--muted);margin-bottom:6px">Factor breakdown</div>
            <div id="dfact"></div>
          </div>
          <div>
            <div style="font-size:9px;color:var(--muted);margin-bottom:5px">Risk parameters</div>
            <div class="rg" id="drisk"></div>
            <div id="dnote" style="font-size:9px;color:var(--muted);margin-top:5px"></div>
          </div>
          <div>
            <div style="font-size:9px;color:var(--muted);margin-bottom:5px">Market regime</div>
            <div id="dreg"></div>
          </div>
        </div>
      </div>
      <div id="dcf" class="cfb" style="display:none"></div>
      <div id="dwarn"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="card">
        <div class="ct2">Open positions</div>
        <table class="pt"><thead><tr><th>Symbol</th><th>Qty</th><th>Cost</th><th>Price</th><th>P&L</th></tr></thead>
        <tbody id="ptb"><tr><td colspan="5" style="color:var(--muted);padding:14px">No open positions</td></tr></tbody></table>
      </div>
      <div class="card"><div class="ct2">Paper equity curve</div><div class="cw"><canvas id="eqc"></canvas></div></div>
    </div>
    <div class="card">
      <div class="ct2">Black swan stress tests — regime-aware</div>
      <div class="sg" id="stg"><div class="empty" style="grid-column:1/-1">Computing...</div></div>
      <div id="stsum" style="font-size:9px;color:var(--muted);margin-top:8px"></div>
    </div>
  </div>
</div>
<script>
const io_sock = io({transports:['websocket','polling']});
let signals={}, sel=null, eq=[100000], chart=null, sd='confidence';

io_sock.on('connect',()=>{
  document.getElementById('cdot').style.background='var(--green)';
  document.getElementById('scl').textContent='Connected';
  document.getElementById('scl').style.color='var(--green)';
});
io_sock.on('disconnect',()=>{
  document.getElementById('cdot').style.background='var(--red)';
  document.getElementById('scl').textContent='Disconnected';
  document.getElementById('scl').style.color='var(--red)';
});
io_sock.on('signals_update',d=>{
  (d.signals||[]).forEach(s=>{signals[s.symbol]=s;});
  renderSidebar();updateMets();
  if(sel&&signals[sel])renderDetail(signals[sel]);
});
io_sock.on('new_signal',s=>{signals[s.symbol]=s;renderSidebar();updateMets();});
io_sock.on('prices_update',d=>{
  document.getElementById('ht').textContent=new Date().toLocaleTimeString();
  document.getElementById('hs').textContent=Object.keys(d.prices||{}).length;
  Object.entries(d.prices||{}).forEach(([sym,p])=>{
    const el=document.getElementById('p-'+sym.replace(/[^a-z0-9]/gi,'_'));
    if(!el)return;
    el.className=p.direction==='up'?'up':p.direction==='down'?'dn':'fl';
    el.textContent=p.price!=null?'$'+Number(p.price).toLocaleString(undefined,{maximumFractionDigits:2}):'';
  });
});
io_sock.on('portfolio_update',d=>{
  const val=d.current_portfolio_value||100000;
  const ret=d.total_return_pct||0;
  document.getElementById('mpv').textContent='$'+Math.round(val).toLocaleString();
  document.getElementById('mpv').style.color=ret>=0?'var(--green)':'var(--red)';
  document.getElementById('mret').textContent=(ret>=0?'+':'')+ret.toFixed(2)+'%';
  document.getElementById('mret').style.color=ret>=0?'var(--green)':'var(--red)';
  document.getElementById('hp').textContent='$'+Math.round(val).toLocaleString();
  document.getElementById('mwr').textContent=d.win_rate_pct!=null?d.win_rate_pct.toFixed(1)+'%':'—';
  eq.push(val);if(eq.length>200)eq.shift();updateChart();
  if(d.kill_switch_active&&!document.getElementById('ksb')){
    const b=document.createElement('div');b.id='ksb';
    b.style.cssText='background:rgba(239,68,68,.13);border:1px solid var(--red);border-radius:5px;padding:7px 12px;font-size:10px;color:var(--red);margin-bottom:10px';
    b.textContent='KILL SWITCH ACTIVE — drawdown limit hit. No new orders.';
    document.querySelector('.content').prepend(b);
  }
});
io_sock.on('stress_update',renderStress);
io_sock.on('latency_update',d=>{
  const l=document.getElementById('sl');
  l.textContent=d.avg_latency_ms!=null?d.avg_latency_ms.toFixed(0):'—';
  l.style.color=d.avg_latency_ms<500?'var(--green)':'var(--amber)';
  document.getElementById('sp').textContent=d.p95_ms!=null?d.p95_ms.toFixed(0):'—';
});

function renderSidebar(){
  const el=document.getElementById('slist');
  let arr=Object.values(signals);
  if(!arr.length){el.innerHTML='<div class="empty">No signals yet...</div>';return;}
  arr.sort((a,b)=>sd==='symbol'?a.symbol.localeCompare(b.symbol):
    ((a.signal==='buy'?0:a.signal==='sell'?1:2)-(b.signal==='buy'?0:b.signal==='sell'?1:2)||b.confidence-a.confidence));
  el.innerHTML=arr.map(s=>{
    const dir=s.signal||'neutral',conf=Math.round((s.confidence||0)*100),conv=(s.conviction_score||0).toFixed(1);
    const bc=dir==='buy'?'var(--green)':dir==='sell'?'var(--red)':'var(--faint)';
    const rc=s.regime==='stressed'?'var(--amber)':s.regime==='crisis'?'var(--red)':'var(--muted)';
    const safe=s.symbol.replace(/[^a-z0-9]/gi,'_');
    return`<div class="si${s.symbol===sel?' active':''}" onclick="selectSig('${s.symbol}')">
      <div class="sr"><span class="ssym">${s.symbol}</span><span class="badge b-${dir}">${dir}</span></div>
      <div class="sr"><span class="smeta"><span>conv ${conv}/10</span><span>conf ${conf}%</span><span style="color:${rc}">${s.regime||''}</span></span>
      <span id="p-${safe}" class="fl"></span></div>
      <div class="ct"><div class="cf" style="width:${conf}%;background:${bc}"></div></div>
    </div>`;
  }).join('');
  document.getElementById('hsi').textContent=arr.length;
}

function updateMets(){
  const arr=Object.values(signals);
  const buys=arr.filter(s=>s.signal==='buy').length,sells=arr.filter(s=>s.signal==='sell').length;
  document.getElementById('mns').textContent=arr.length;
  document.getElementById('msp').textContent=`${buys} buy · ${sells} sell · ${arr.length-buys-sells} hold`;
}

function selectSig(sym){
  sel=sym;renderSidebar();
  io_sock.emit('subscribe_symbol',{symbol:sym});
  if(signals[sym])renderDetail(signals[sym]);
}

const FLABELS={trend:'Trend',momentum:'Momentum',mean_revert:'Mean Rev',volume:'Volume',sentiment:'Sentiment'};
const FWEIGHTS={trend:30,momentum:25,mean_revert:20,volume:15,sentiment:10};

function renderDetail(s){
  document.getElementById('dsym').textContent=s.symbol;
  const conv=s.conviction_score||0;
  const ce=document.getElementById('dconv');
  ce.textContent=conv.toFixed(1);
  ce.style.color=s.signal==='buy'?'var(--green)':s.signal==='sell'?'var(--red)':'var(--muted)';
  document.getElementById('dconf').textContent='conf '+Math.round((s.confidence||0)*100)+'%';
  renderWF(s.waterfall_data||s.top_drivers||[]);
  const fac=s.factor_scores||{};
  document.getElementById('dfact').innerHTML=Object.entries(fac).map(([k,v])=>{
    const pct=Math.min(100,Math.abs(v)*100).toFixed(0);
    const col=v>0.05?'var(--green)':v<-0.05?'var(--red)':'var(--faint)';
    return`<div class="fr"><span class="fn">${FLABELS[k]||k}</span><div class="fb"><div class="ff" style="width:${pct}%;background:${col}"></div></div>
    <span class="fv" style="color:${col}">${v>0?'+':''}${Number(v).toFixed(3)}</span><span class="fw">${FWEIGHTS[k]||0}%w</span></div>`;
  }).join('')+(s.regime_multiplier!=null?`<div style="font-size:9px;color:var(--muted);margin-top:4px;padding-top:4px;border-top:1px solid var(--border)">
    Regime: <span style="color:${s.regime==='stressed'?'var(--amber)':s.regime==='crisis'?'var(--red)':'var(--muted)'}">${s.regime||'normal'}</span>
    · signals at ${Math.round((s.regime_multiplier||1)*100)}%</div>`:'');
  const risk=s.risk_parameters||{};
  document.getElementById('drisk').innerHTML=[
    ['Stop loss',risk.stop_loss_pct?risk.stop_loss_pct+'%':'—'],
    ['Take profit',risk.take_profit_pct?risk.take_profit_pct+'%':'—'],
    ['Position size',risk.suggested_position_size_pct?risk.suggested_position_size_pct+'%':'—'],
    ['R:R',risk.risk_reward_ratio?risk.risk_reward_ratio+':1':'—'],
  ].map(([l,v])=>`<div class="ri"><div class="rl">${l}</div><div class="rv">${v}</div></div>`).join('');
  document.getElementById('dnote').textContent=risk.entry_note||'';
  const reg=s.regime_context||{};
  document.getElementById('dreg').innerHTML=Object.entries(reg).filter(([k])=>!k.includes('score')).map(([k,v])=>{
    const bg=(v==='stressed'||v==='risk-off')?'rgba(239,68,68,.1);color:var(--red)':(v==='calm'||v==='risk-on')?'rgba(34,197,94,.1);color:var(--green)':'var(--border);color:var(--muted)';
    return`<span class="rp" style="background:${bg}">${k}: ${v}</span>`;
  }).join('');
  const cf=s.counterfactual;
  const cfe=document.getElementById('dcf');
  if(cf){cfe.textContent=cf;cfe.style.display='block';}else{cfe.style.display='none';}
  document.getElementById('dwarn').innerHTML=(s.macro_warnings||[]).map(w=>`<div class="wb">${w}</div>`).join('');
}

function renderWF(drivers){
  const el=document.getElementById('dwf');
  if(!drivers||!drivers.length){
    el.innerHTML='<div style="color:var(--muted);font-size:10px;padding:8px">SHAP values appear after model training (Phase 3). Factor scores shown above.</div>';return;
  }
  const mx=Math.max(...drivers.map(d=>Math.abs(d.shap_value||d.value||0)),0.001);
  el.innerHTML=drivers.slice(0,10).map(d=>{
    const v=d.shap_value||d.value||0,pct=(Math.abs(v)/mx*100).toFixed(0),isP=v>0,lb=d.label||d.feature||'—';
    return`<div class="wr"><div class="wl" title="${lb}">${lb}</div><div class="wt">
    ${isP?`<div class="wp" style="width:${pct}%">${v>0?'+':''}${v.toFixed(3)}</div>`:`<div class="wn" style="width:${pct}%">${v.toFixed(3)}</div>`}
    </div></div>`;
  }).join('');
}

function renderStress(data){
  if(!data||!Object.keys(data).length)return;
  const grid=document.getElementById('stg');
  const entries=Object.entries(data).filter(([k])=>k!=='summary'&&typeof data[k]==='object');
  if(!entries.length)return;
  const sum=data.summary||{};
  if(sum.overall_grade){
    const sg=document.getElementById('msg');
    sg.textContent=sum.overall_grade;
    sg.style.color={A:'var(--green)',B:'var(--blue)',C:'var(--amber)',F:'var(--red)'}[sum.overall_grade]||'var(--amber)';
    document.getElementById('msgs').textContent=(sum.pass_rate_pct||0)+'% passed · '+(sum.avg_crisis_protection_pct||0)+'% avg protection';
    document.getElementById('stsum').textContent=sum.assessment||'';
  }
  grid.innerHTML=entries.map(([name,r])=>{
    const dd=r.max_drawdown_pct||0,mdd=r.market_drawdown_pct||0,prot=r.protection||0,ret=r.period_return_pct||0;
    const dc=dd>-10?'var(--green)':dd>-20?'var(--amber)':'var(--red)';
    return`<div class="sc ${r.survived?'pass':'fail'}" title="${r.description||''}">
      <div class="sn">${name}</div>
      <div class="sd" style="color:${dc}">${dd.toFixed(1)}% DD</div>
      <div class="sm">vs market ${mdd.toFixed(1)}%</div>
      ${prot>0?`<div class="sm" style="color:var(--green)">+${prot.toFixed(0)}% protected</div>`:''}
      <div class="sm" style="color:${ret>=0?'var(--green)':'var(--red)'}">${ret>=0?'+':''}${ret.toFixed(1)}% · ${r.survived?'pass':'fail'}</div>
    </div>`;
  }).join('');
}

function initChart(){
  const ctx=document.getElementById('eqc').getContext('2d');
  chart=new Chart(ctx,{type:'line',data:{labels:eq.map((_,i)=>i),datasets:[{data:eq,borderColor:'#3b82f6',borderWidth:1.5,fill:true,backgroundColor:'rgba(59,130,246,0.05)',pointRadius:0,tension:.3}]},
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
  scales:{x:{display:false},y:{ticks:{color:'#5a6478',font:{size:9,family:'JetBrains Mono'},callback:v=>'$'+Math.round(v).toLocaleString()},grid:{color:'rgba(255,255,255,0.03)'}}}}});
}
function updateChart(){
  if(!chart)return;
  chart.data.labels=eq.map((_,i)=>i);chart.data.datasets[0].data=[...eq];
  chart.data.datasets[0].borderColor=eq[eq.length-1]>=(eq[0]||eq[eq.length-1])?'#22c55e':'#ef4444';
  chart.update('none');
}

function refreshPos(){
  fetch('/api/positions').then(r=>r.json()).then(d=>{
    const tb=document.getElementById('ptb');
    if(!(d.positions||[]).length){tb.innerHTML='<tr><td colspan="5" style="color:var(--muted);padding:12px">No open positions</td></tr>';return;}
    tb.innerHTML=d.positions.map(p=>{const pnl=p.unrealized_pnl||0;return`<tr><td style="font-weight:500">${p.symbol}</td><td>${p.quantity}</td><td>$${Number(p.avg_cost||0).toFixed(2)}</td><td>${p.current_price?'$'+Number(p.current_price).toFixed(2):'—'}</td><td style="color:${pnl>=0?'var(--green)':'var(--red)'}">${pnl>=0?'+':''}$${Math.abs(pnl).toFixed(0)}</td></tr>`;}).join('');
  }).catch(()=>{});
}

function updateUptime(){
  fetch('/api/health').then(r=>r.json()).then(d=>{
    const s=d.uptime_seconds||0,h=Math.floor(s/3600),m=Math.floor((s%3600)/60),sc=s%60;
    document.getElementById('hu').textContent=h>0?`${h}h ${m}m`:m>0?`${m}m ${sc}s`:`${sc}s`;
  }).catch(()=>{});
}

initChart();
fetch('/api/signals').then(r=>r.json()).then(d=>{(d.signals||[]).forEach(s=>{signals[s.symbol]=s;});renderSidebar();updateMets();}).catch(()=>{});
fetch('/api/portfolio').then(r=>r.json()).then(d=>{if(d.current_portfolio_value){eq=[d.current_portfolio_value];updateChart();}}).catch(()=>{});
fetch('/api/stress-test').then(r=>r.json()).then(renderStress).catch(()=>{});
refreshPos();updateUptime();
setInterval(refreshPos,5000);setInterval(updateUptime,10000);
setInterval(()=>fetch('/api/stress-test').then(r=>r.json()).then(renderStress),30000);
</script>
</body>
</html>
"""


# ─────────────────────────────────────────────────────────────
# Standalone launcher
# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(name)-28s | %(levelname)-7s | %(message)s",
    )
    for lib in ["urllib3", "yfinance", "peewee", "transformers", "engineio", "socketio"]:
        logging.getLogger(lib).setLevel(logging.WARNING)

    # Load .env
    env_path = ROOT / ".env"
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                os.environ.setdefault(k.strip(), v.strip())
        logger.info(f"Loaded .env from {env_path}")

    port = int(os.environ.get("PORT", 5050))

    print(f"""
╔══════════════════════════════════════════════════╗
║  MacroIntel — Full System                        ║
║  Dashboard:   http://localhost:{port}             ║
║  Diagnostics: http://localhost:{port}/api/diagnostics ║
╚══════════════════════════════════════════════════╝
    """)

    try:
        from run import MacroIntelligenceSystem
        system = MacroIntelligenceSystem()
        system.start(run_dashboard=True, run_realtime=True,
                     run_backtest=True, dashboard_port=port)
    except ImportError as e:
        logger.warning(f"run.py not importable ({e}), starting dashboard-only mode...")

        from core.realtime_engine import PRICE_BUFFER, PollingFallback
        from core.paper_trading import VirtualBroker
        from core.signal_engine_v2 import RegimeAwareStressTester, MultiFactorScorer
        from core.explainability import SignalExplainer

        symbols = ["AAPL","MSFT","NVDA","GOOGL","META","AMZN","TSLA","JPM","SPY",
                   "QQQ","GLD","TLT","RELIANCE.NS","TCS.NS","INFY.NS","^NSEI","^VIX"]
        PollingFallback(symbols=symbols, interval_seconds=15, buffer=PRICE_BUFFER).start()
        broker  = VirtualBroker(initial_capital=100_000)
        sig_store: Dict = {}
        stress: Dict    = {}

        def _stress():
            r = RegimeAwareStressTester().run_regime_aware_stress_tests()
            stress.update(r)
        threading.Thread(target=_stress, daemon=True).start()

        def _infer():
            scorer   = MultiFactorScorer()
            explainer = SignalExplainer()
            while True:
                try:
                    from pipeline.price_collector import PriceDataPipeline
                    from pipeline.feature_engineering import FeaturePipeline
                    pd_res = PriceDataPipeline().run_incremental_update()
                    fms    = FeaturePipeline().build_feature_matrix(price_data=pd_res.get("price_daily_recent",{}))
                    for sym, feats in list(fms.items())[:30]:
                        if feats.empty: continue
                        row    = feats.iloc[-1]
                        scored = scorer.score(row)
                        sig    = explainer.explain_prediction(
                            symbol=sym, features=feats.iloc[[-1]],
                            model_predictions=scored["factor_scores"],
                            ensemble_score=scored["final_score"],
                            feature_names=[c for c in feats.columns if feats[c].dtype != object],
                        )
                        sig.update({"signal": scored["direction"], "confidence": scored["confidence"],
                                    "conviction_score": scored["conviction_score"],
                                    "regime": scored["regime"],
                                    "regime_multiplier": scored["regime_multiplier"],
                                    "factor_scores": scored["factor_scores"]})
                        sig_store[sym] = sig
                    b = sum(1 for s in sig_store.values() if s.get("signal")=="buy")
                    s = sum(1 for s in sig_store.values() if s.get("signal")=="sell")
                    logger.info(f"Signals: {b} BUY | {s} SELL | {len(sig_store)-b-s} HOLD")
                except Exception as ex:
                    logger.error(f"Inference: {ex}")
                time.sleep(300)

        threading.Thread(target=_infer, daemon=True).start()
        app, socketio = create_app(price_buffer=PRICE_BUFFER, paper_broker=broker,
                                   signal_store=sig_store, stress_results=stress)
        socketio.run(app, host="0.0.0.0", port=port, debug=False, use_reloader=False)
